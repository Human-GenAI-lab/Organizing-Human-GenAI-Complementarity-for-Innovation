version 16.0
set more off
set graphics on
graph set window fontface "Arial"
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/figures"

use "$ROOT/data/empirical_analysis.dta", clear

* Figure 8
_pctile ego_network_density_c, p(25 75)
local dl = r(r1)
local dh = r(r2)

_pctile network_centrality_c, p(25 75)
local cl = r(r1)
local ch = r(r2)

quietly summarize information_complementarity
local icmean_raw = r(mean)

quietly reg incremental_innovation ///
c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
capability_complementarity_c ///
firm_size ///
firm_age ///
prior_innovation_stock ///
prior_invention_stock ///
prior_ai_genai_patent_stock ///
direct_partners_log ///
genai_use_intensity ///
genai_adoption_maturity ///
digital_capability ///
i.ownership_n ///
i.industry_n ///
i.province_n, ///
vce(hc3)

quietly lincom ///
_b[information_complementarity_c] + ///
`dh' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dh' * `cl') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local bA1 = r(estimate)
local pA1 = r(p)
local starsA1 = cond(`pA1'<.01,"***",cond(`pA1'<.05,"**",cond(`pA1'<.10,"*","")))
local seA1 = r(se)

quietly lincom ///
_b[information_complementarity_c] + ///
`dl' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dl' * `ch') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local bA2 = r(estimate)
local pA2 = r(p)
local starsA2 = cond(`pA2'<.01,"***",cond(`pA2'<.05,"**",cond(`pA2'<.10,"*","")))
local seA2 = r(se)

quietly margins, at(information_complementarity_c=0 ///
                    ego_network_density_c=`dh' ///
                    network_centrality_c=`cl')
matrix MT = r(table)
local aA1 = MT[1,1]

quietly margins, at(information_complementarity_c=0 ///
                    ego_network_density_c=`dl' ///
                    network_centrality_c=`ch')
matrix MT = r(table)
local aA2 = MT[1,1]

preserve
clear
set obs 7
generate xraw = _n
generate double xcen = xraw - `icmean_raw'
generate double ysolid  = `aA1' + `bA1' * xcen
generate double ydashed = `aA2' + `bA2' * xcen

generate str28 labsolid = ""
replace  labsolid = "b = " + string(`bA1', "%4.3f") + "`starsA1'" + " (" + string(`seA1', "%4.3f") + ")" in 2
generate str28 labdash = ""
replace  labdash = "b = " + string(`bA2', "%4.3f") + "`starsA2'" + " (" + string(`seA2', "%4.3f") + ")" in 2

twoway ///
(line ysolid xraw, lcolor(black) lpattern(solid) lwidth(medthick)) ///
(line ydashed xraw, lcolor(black) lpattern(dash) lwidth(medthick)) ///
(scatter ysolid xraw if xraw==2, msymbol(i) mlabel(labsolid) ///
         mlabcolor(black) mlabsize(medium) mlabpos(6) mlabangle(22)) ///
(scatter ydashed xraw if xraw==2, msymbol(i) mlabel(labdash) ///
         mlabcolor(black) mlabsize(medium) mlabpos(12) mlabangle(6)), ///
title("Information Complementarity and Incremental Innovation", size(medlarge) color(black)) ///
xtitle("Information Complementarity", size(medlarge)) ///
ytitle("Predicted Incremental Innovation", size(medlarge)) ///
xlabel(1(1)7, labsize(medlarge)) ///
ylabel(, angle(horizontal) labsize(medlarge) format(%4.2f)) ///
legend(order(1 "High density / Low centrality" ///
             2 "Low density / High centrality") ///
       cols(1) size(medium) position(6) ring(1)) ///
scheme(s2color) ///
name(Figure8A_final, replace)

graph export ///
"$ROOT/outputs/figures/Figure_8_Panel_A_IC_H2a.png", ///
replace width(2200)

restore

quietly summarize capability_complementarity
local ccmean_raw = r(mean)

quietly reg radical_innovation ///
c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
information_complementarity_c ///
firm_size ///
firm_age ///
prior_innovation_stock ///
prior_invention_stock ///
prior_ai_genai_patent_stock ///
direct_partners_log ///
genai_use_intensity ///
genai_adoption_maturity ///
digital_capability ///
i.ownership_n ///
i.industry_n ///
i.province_n, ///
vce(hc3)

quietly lincom ///
_b[capability_complementarity_c] + ///
`dh' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dh' * `cl') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local bB1 = r(estimate)
local pB1 = r(p)
local starsB1 = cond(`pB1'<.01,"***",cond(`pB1'<.05,"**",cond(`pB1'<.10,"*","")))
local seB1 = r(se)

quietly lincom ///
_b[capability_complementarity_c] + ///
`dl' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dl' * `ch') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local bB2 = r(estimate)
local pB2 = r(p)
local starsB2 = cond(`pB2'<.01,"***",cond(`pB2'<.05,"**",cond(`pB2'<.10,"*","")))
local seB2 = r(se)

quietly margins, at(capability_complementarity_c=0 ///
                    ego_network_density_c=`dh' ///
                    network_centrality_c=`cl')
matrix MT = r(table)
local aB1 = MT[1,1]

quietly margins, at(capability_complementarity_c=0 ///
                    ego_network_density_c=`dl' ///
                    network_centrality_c=`ch')
matrix MT = r(table)
local aB2 = MT[1,1]

preserve
clear
set obs 7
generate xraw = _n
generate double xcen = xraw - `ccmean_raw'
generate double ysolid  = `aB1' + `bB1' * xcen
generate double ydashed = `aB2' + `bB2' * xcen

generate str28 labsolid = ""
replace  labsolid = "b = " + string(`bB1', "%4.3f") + "`starsB1'" + " (" + string(`seB1', "%4.3f") + ")" in 2
generate str28 labdash = ""
replace  labdash = "b = " + string(`bB2', "%4.3f") + "`starsB2'" + " (" + string(`seB2', "%4.3f") + ")" in 3

twoway ///
(line ysolid xraw, lcolor(black) lpattern(solid) lwidth(medthick)) ///
(line ydashed xraw, lcolor(black) lpattern(dash) lwidth(medthick)) ///
(scatter ysolid xraw if xraw==2, msymbol(i) mlabel(labsolid) ///
         mlabcolor(black) mlabsize(medium) mlabpos(12) mlabangle(8)) ///
(scatter ydashed xraw if xraw==3, msymbol(i) mlabel(labdash) ///
         mlabcolor(black) mlabsize(medium) mlabpos(6) mlabangle(24)), ///
title("Capability Complementarity and Radical Innovation", size(medlarge) color(black)) ///
xtitle("Capability Complementarity", size(medlarge)) ///
ytitle("Predicted Radical Innovation", size(medlarge)) ///
xlabel(1(1)7, labsize(medlarge)) ///
ylabel(, angle(horizontal) labsize(medlarge) format(%4.2f)) ///
legend(order(1 "High density / Low centrality" ///
             2 "Low density / High centrality") ///
       cols(1) size(medium) position(6) ring(1)) ///
scheme(s2color) ///
name(Figure8B_final, replace)

graph export ///
"$ROOT/outputs/figures/Figure_8_Panel_B_CC_H2b.png", ///
replace width(2200)

display as result "Figure 8 panels exported separately."
display as result "Panel A exported to Figure_8_Panel_A_IC_H2a.png"
display as result "Panel B exported to Figure_8_Panel_B_CC_H2b.png"

