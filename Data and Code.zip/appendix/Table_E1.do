version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table E1

use "$ROOT/data/empirical_analysis.dta", clear
local CV information_complementarity capability_complementarity ego_network_density ///
    network_centrality incremental_innovation radical_innovation genai_use_intensity ///
    genai_adoption_maturity digital_capability firm_size firm_age prior_innovation_stock ///
    prior_invention_stock prior_ai_genai_patent_stock direct_partners_log
quietly correlate `CV'
matrix CORR = r(C)
local corr_n = r(N)

clear
set obs 16
forvalues j = 1/16 {
    generate str52 c`j' = ""
}
replace c1 = "Variable" in 1
forvalues j = 1/15 {
    local column = `j' + 1
    replace c`column' = "`j'" in 1
}
local label1  "Information Complementarity"
local label2  "Capability Complementarity"
local label3  "Ego-network Density"
local label4  "Network Centrality"
local label5  "Incremental Innovation"
local label6  "Radical Innovation"
local label7  "GenAI Use Intensity"
local label8  "GenAI Adoption Maturity"
local label9  "Digital Capability"
local label10 "Firm Size"
local label11 "Firm Age"
local label12 "Prior Innovation Stock"
local label13 "Prior Invention Patent Stock"
local label14 "Prior AI/GenAI Patent Stock"
local label15 "Direct Supply-chain Partners"

forvalues i = 1/15 {
    local row = `i' + 1
    replace c1 = "`i'. `label`i''" in `row'
    forvalues j = 1/15 {
        local column = `j' + 1
        if `j' == `i' replace c`column' = "--" in `row'
        else if `j' < `i' {
            scalar rho = CORR[`i',`j']
            scalar t_corr = rho*sqrt((`corr_n'-2)/(1-rho^2))
            scalar p_corr = 2*ttail(`corr_n'-2,abs(t_corr))
            local stars ""
            if p_corr < 0.01 local stars "***"
            else if p_corr < 0.05 local stars "**"
            else if p_corr < 0.10 local stars "*"
            local formatted = trim(string(rho,"%5.2f")) + "`stars'"
            replace c`column' = "`formatted'" in `row'
        }
    }
}

local nr=_N
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",9)
putdocx paragraph
putdocx text ("Table E1. "), bold
putdocx text ("Correlations among the Study Variables")
putdocx table tc1 = data("c1 c2 c3 c4 c5 c6 c7 c8 c9 c10 c11 c12 c13 c14 c15 c16"), border(all,single,black) layout(autofitwindow) headerrow(1)
putdocx table tc1(.,.), font("Arial",9) valign(center)
putdocx table tc1(1,.), bold halign(center)
putdocx table tc1(2/`nr',1), halign(left)
putdocx table tc1(2/`nr',2/16), halign(center)
putdocx save "$ROOT/outputs/tables/Table_E1.docx", replace
