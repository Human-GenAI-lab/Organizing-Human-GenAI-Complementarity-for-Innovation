version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table 2
tempfile table_data

capture program drop wcell
program define wcell, rclass
    syntax, Model(name) Term(string)
    quietly estimates restore `model'
    capture scalar wb = _b[`term']
    if _rc {
        return local text ""
        exit
    }
    scalar ws = _se[`term']
    scalar wp = 2*ttail(e(df_r),abs(wb/ws))
    local st ""
    if wp < 0.01 local st "***"
    else if wp < 0.05 local st "**"
    else if wp < 0.10 local st "*"
    local bs = trim(string(wb,"%9.3f"))
    local ss = trim(string(ws,"%9.3f"))
    return local text "`bs'`st' (`ss')"
end

use "$ROOT/data/empirical_analysis.dta", clear

quietly reg incremental_innovation ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W1

quietly reg incremental_innovation ///
information_complementarity_c capability_complementarity_c ///
ego_network_density_c network_centrality_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W2

quietly reg incremental_innovation ///
information_complementarity_c capability_complementarity_c ///
ego_network_density_c network_centrality_c ///
c.information_complementarity_c#c.ego_network_density_c ///
c.information_complementarity_c#c.network_centrality_c ///
c.ego_network_density_c#c.network_centrality_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W3

quietly reg incremental_innovation ///
c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
capability_complementarity_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W4

quietly reg radical_innovation ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W5

quietly reg radical_innovation ///
information_complementarity_c capability_complementarity_c ///
ego_network_density_c network_centrality_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W6

quietly reg radical_innovation ///
information_complementarity_c capability_complementarity_c ///
ego_network_density_c network_centrality_c ///
c.capability_complementarity_c#c.ego_network_density_c ///
c.capability_complementarity_c#c.network_centrality_c ///
c.ego_network_density_c#c.network_centrality_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W7

quietly reg radical_innovation ///
c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
information_complementarity_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)
estimates store W8

tempname T2
postfile `T2' str42 c1 str24 c2 str24 c3 str24 c4 str24 c5 ///
str24 c6 str24 c7 str24 c8 str24 c9 ///
using `table_data', replace

post `T2' ("Dependent variable") ("Incremental innovation") ("") ("") ("") ///
("Radical innovation") ("") ("") ("")
post `T2' ("Variable") ("Model 1") ("Model 2") ("Model 3") ("Model 4") ///
("Model 5") ("Model 6") ("Model 7") ("Model 8")

local terms ///
information_complementarity_c ///
capability_complementarity_c ///
ego_network_density_c ///
network_centrality_c ///
c.information_complementarity_c#c.ego_network_density_c ///
c.information_complementarity_c#c.network_centrality_c ///
c.capability_complementarity_c#c.ego_network_density_c ///
c.capability_complementarity_c#c.network_centrality_c ///
c.ego_network_density_c#c.network_centrality_c ///
c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c ///
c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c ///
firm_size ///
firm_age ///
prior_innovation_stock ///
prior_invention_stock ///
prior_ai_genai_patent_stock ///
direct_partners_log ///
genai_use_intensity ///
genai_adoption_maturity ///
digital_capability ///
_cons

local labs ///
Information_complementarity ///
Capability_complementarity ///
Ego-network_density ///
Network_centrality ///
IC_x_Density ///
IC_x_Centrality ///
CC_x_Density ///
CC_x_Centrality ///
Density_x_Centrality ///
IC_x_Density_x_Centrality ///
CC_x_Density_x_Centrality ///
Firm_size ///
Firm_age ///
Prior_innovation_stock ///
Prior_invention_patent_stock ///
Prior_AI/GenAI_patent_stock ///
Direct_supply-chain_partners ///
GenAI_use_intensity ///
GenAI_adoption_maturity ///
Digital_capability ///
Constant

local nt : word count `terms'
local nl : word count `labs'
assert `nt' == `nl'

forvalues i=1/`nt' {
    local tr : word `i' of `terms'
    local lb : word `i' of `labs'
    local lb : subinstr local lb "_" " ", all

    forvalues m=1/8 {
        quietly wcell, model(W`m') term("`tr'")
        local v`m' "`r(text)'"
    }

    post `T2' ("`lb'") ("`v1'") ("`v2'") ("`v3'") ("`v4'") ///
        ("`v5'") ("`v6'") ("`v7'") ("`v8'")
}

post `T2' ("Ownership controls") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes")
post `T2' ("Industry fixed effects") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes")
post `T2' ("Province fixed effects") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes") ("Yes")

forvalues m=1/8 {
    estimates restore W`m'
    local n`m'=trim(string(e(N),"%9.0f"))
    local r`m'=trim(string(e(r2),"%9.3f"))
    local a`m'=trim(string(e(r2_a),"%9.3f"))
}
post `T2' ("Observations") ("`n1'") ("`n2'") ("`n3'") ("`n4'") ("`n5'") ("`n6'") ("`n7'") ("`n8'")
post `T2' ("R-squared") ("`r1'") ("`r2'") ("`r3'") ("`r4'") ("`r5'") ("`r6'") ("`r7'") ("`r8'")
post `T2' ("Adjusted R-squared") ("`a1'") ("`a2'") ("`a3'") ("`a4'") ("`a5'") ("`a6'") ("`a7'") ("`a8'")
postclose `T2'

use `table_data', clear
local nr=_N
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",9)
putdocx paragraph
putdocx text ("Table 2. "), bold
putdocx text ("Regression Results for Innovation Outcomes")
putdocx table t2 = data("c1 c2 c3 c4 c5 c6 c7 c8 c9"), border(all,nil) layout(autofitwindow) headerrow(2)
putdocx table t2(.,.), font("Arial",9) valign(center)
putdocx table t2(1,.), bold halign(center) border(top,single,black)
putdocx table t2(1,6), colspan(4)
putdocx table t2(1,2), colspan(4)
putdocx table t2(2,.), bold halign(center) border(bottom,single,black)
putdocx table t2(3/`nr',1), halign(left)
putdocx table t2(3/`nr',2/9), halign(center)
putdocx table t2(`nr',.), border(bottom,single,black)
putdocx save "$ROOT/outputs/tables/Table_2.docx", replace

