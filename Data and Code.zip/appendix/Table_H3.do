version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table H3

tempfile numeric_results
local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock ///
    direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability ///
    i.ownership_n i.industry_n i.province_n

use "$ROOT/data/empirical_analysis.dta", clear

tempname E4
postfile `E4' str44 specification str4 path double N triple triple_se triple_p ///
    favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p ///
    using "`numeric_results'", replace

foreach cuts in "20 80" "16 84" {
    tokenize `cuts'
    local lo=`1'
    local hi=`2'
    _pctile ego_network_density_c, p(`lo' `hi')
    local dlx=r(r1)
    local dhx=r(r2)
    _pctile network_centrality_c, p(`lo' `hi')
    local clx=r(r1)
    local chx=r(r2)
    local spec "`lo'th/`hi'th percentiles"

    quietly reg incremental_innovation c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
        capability_complementarity_c `C', vce(hc3)
    local b=_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local s=_se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local p=2*ttail(e(df_r),abs(`b'/`s'))
    quietly lincom _b[information_complementarity_c] + `dhx'*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
        `clx'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dhx'*`clx')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local fs=r(estimate)
    local fse=r(se)
    local fp=r(p)
    quietly lincom (`dhx'-`dlx')*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
        (`clx'-`chx')*_b[c.information_complementarity_c#c.network_centrality_c] + ///
        ((`dhx'*`clx')-(`dlx'*`chx'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    post `E4' ("`spec'") ("H2a") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

    quietly reg radical_innovation c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
        information_complementarity_c `C', vce(hc3)
    local b=_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local s=_se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local p=2*ttail(e(df_r),abs(`b'/`s'))
    quietly lincom _b[capability_complementarity_c] + `dlx'*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
        `chx'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dlx'*`chx')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local fs=r(estimate)
    local fse=r(se)
    local fp=r(p)
    quietly lincom (`dlx'-`dhx')*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
        (`chx'-`clx')*_b[c.capability_complementarity_c#c.network_centrality_c] + ///
        ((`dlx'*`chx')-(`dhx'*`clx'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    post `E4' ("`spec'") ("H2b") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
}

preserve
_pctile network_centrality, p(99)
keep if network_centrality <= r(r1)
_pctile ego_network_density_c, p(25 75)
local dlx=r(r1)
local dhx=r(r2)
_pctile network_centrality_c, p(25 75)
local clx=r(r1)
local chx=r(r2)
quietly reg incremental_innovation c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c capability_complementarity_c `C', vce(hc3)
local b=_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dhx'*_b[c.information_complementarity_c#c.ego_network_density_c] + `clx'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dhx'*`clx')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dhx'-`dlx')*_b[c.information_complementarity_c#c.ego_network_density_c] + (`clx'-`chx')*_b[c.information_complementarity_c#c.network_centrality_c] + ((`dhx'*`clx')-(`dlx'*`chx'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E4' ("Exclude top 1% of eigenvector centrality") ("H2a") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
quietly reg radical_innovation c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c information_complementarity_c `C', vce(hc3)
local b=_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dlx'*_b[c.capability_complementarity_c#c.ego_network_density_c] + `chx'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dlx'*`chx')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dlx'-`dhx')*_b[c.capability_complementarity_c#c.ego_network_density_c] + (`chx'-`clx')*_b[c.capability_complementarity_c#c.network_centrality_c] + ((`dlx'*`chx')-(`dhx'*`clx'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E4' ("Exclude top 1% of eigenvector centrality") ("H2b") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
restore

preserve
_pctile incremental_patent_count, p(99)
keep if incremental_patent_count <= r(r1)
_pctile ego_network_density_c, p(25 75)
local dlx=r(r1)
local dhx=r(r2)
_pctile network_centrality_c, p(25 75)
local clx=r(r1)
local chx=r(r2)
quietly reg incremental_innovation c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c capability_complementarity_c `C', vce(hc3)
local b=_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dhx'*_b[c.information_complementarity_c#c.ego_network_density_c] + `clx'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dhx'*`clx')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dhx'-`dlx')*_b[c.information_complementarity_c#c.ego_network_density_c] + (`clx'-`chx')*_b[c.information_complementarity_c#c.network_centrality_c] + ((`dhx'*`clx')-(`dlx'*`chx'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E4' ("Exclude top 1% of focal patent count") ("H2a") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
restore

preserve
_pctile radical_invention_count, p(99)
keep if radical_invention_count <= r(r1)
_pctile ego_network_density_c, p(25 75)
local dlx=r(r1)
local dhx=r(r2)
_pctile network_centrality_c, p(25 75)
local clx=r(r1)
local chx=r(r2)
quietly reg radical_innovation c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c information_complementarity_c `C', vce(hc3)
local b=_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dlx'*_b[c.capability_complementarity_c#c.ego_network_density_c] + `chx'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dlx'*`chx')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dlx'-`dhx')*_b[c.capability_complementarity_c#c.ego_network_density_c] + (`chx'-`clx')*_b[c.capability_complementarity_c#c.network_centrality_c] + ((`dlx'*`chx')-(`dhx'*`clx'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E4' ("Exclude top 1% of focal patent count") ("H2b") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
restore

postclose `E4'
use "`numeric_results'", clear
assert _N==8
assert inlist(path,"H2a","H2b")
assert !missing(N,triple,triple_se,triple_p,favored_slope,favored_slope_se,favored_slope_p,planned_contrast,planned_contrast_se,planned_contrast_p)
order specification path N triple triple_se triple_p favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p
sort specification path

capture restore, not
tempfile sensitivity_estimates
save `sensitivity_estimates', replace

tempfile numeric_results
local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock ///
    direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability ///
    i.ownership_n i.industry_n i.province_n

use "$ROOT/data/response_selection.dta", clear
quietly probit valid_response i.ownership_n i.region_n firm_size firm_age prior_innovation prior_invention prior_ai ///
    direct_partners contact_reachability prior_directory_verified
predict xb, xb
generate double imr = normalden(xb)/normal(xb) if valid_response==1
predict phat, pr
generate double ipw = 1/phat if valid_response==1
keep if valid_response==1
keep firm_id imr ipw
tempfile sel
save `sel'

use "$ROOT/data/empirical_analysis.dta", clear
merge 1:1 firm_id using `sel', keep(match) nogen
_pctile ego_network_density_c, p(25 75)
local dl=r(r1)
local dh=r(r2)
_pctile network_centrality_c, p(25 75)
local cl=r(r1)
local ch=r(r2)

tempname E5
postfile `E5' str32 adjustment str4 path double N triple triple_se triple_p ///
    favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p ///
    using "`numeric_results'", replace

quietly reg incremental_innovation c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c capability_complementarity_c imr `C', vce(hc3)
local b=_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dh'*_b[c.information_complementarity_c#c.ego_network_density_c] + `cl'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dh'*`cl')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dh'-`dl')*_b[c.information_complementarity_c#c.ego_network_density_c] + (`cl'-`ch')*_b[c.information_complementarity_c#c.network_centrality_c] + ((`dh'*`cl')-(`dl'*`ch'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E5' ("IMR adjustment") ("H2a") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly reg radical_innovation c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c information_complementarity_c imr `C', vce(hc3)
local b=_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dl'*_b[c.capability_complementarity_c#c.ego_network_density_c] + `ch'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dl'*`ch')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dl'-`dh')*_b[c.capability_complementarity_c#c.ego_network_density_c] + (`ch'-`cl')*_b[c.capability_complementarity_c#c.network_centrality_c] + ((`dl'*`ch')-(`dh'*`cl'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E5' ("IMR adjustment") ("H2b") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly reg incremental_innovation c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c capability_complementarity_c `C' [pweight=ipw], vce(robust)
local b=_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dh'*_b[c.information_complementarity_c#c.ego_network_density_c] + `cl'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dh'*`cl')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dh'-`dl')*_b[c.information_complementarity_c#c.ego_network_density_c] + (`cl'-`ch')*_b[c.information_complementarity_c#c.network_centrality_c] + ((`dh'*`cl')-(`dl'*`ch'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E5' ("Inverse-probability weighting") ("H2a") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly reg radical_innovation c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c information_complementarity_c `C' [pweight=ipw], vce(robust)
local b=_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s=_se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p=2*ttail(e(df_r),abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dl'*_b[c.capability_complementarity_c#c.ego_network_density_c] + `ch'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dl'*`ch')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dl'-`dh')*_b[c.capability_complementarity_c#c.ego_network_density_c] + (`ch'-`cl')*_b[c.capability_complementarity_c#c.network_centrality_c] + ((`dl'*`ch')-(`dh'*`cl'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E5' ("Inverse-probability weighting") ("H2b") (e(N)) (`b') (`s') (`p') (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
postclose `E5'

use "`numeric_results'", clear
assert _N==4
assert inlist(path,"H2a","H2b")
assert !missing(N,triple,triple_se,triple_p,favored_slope,favored_slope_se,favored_slope_p,planned_contrast,planned_contrast_se,planned_contrast_p)
order adjustment path N triple triple_se triple_p favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p
sort adjustment path

capture restore, not
tempfile selection_estimates
save `selection_estimates', replace
use `sensitivity_estimates', clear
generate byte panel=cond(strpos(specification,"percentiles"),1,2)
generate byte ord=.
replace ord=1 if specification=="20th/80th percentiles"
replace ord=2 if specification=="16th/84th percentiles"
replace ord=1 if specification=="Exclude top 1% of eigenvector centrality"
replace ord=2 if specification=="Exclude top 1% of focal patent count"
tempfile sensitivity_results
save `sensitivity_results', replace
use `selection_estimates', clear
rename adjustment specification
generate byte panel=3
generate byte ord=cond(specification=="IMR adjustment",1,2)
append using `sensitivity_results'
assert !missing(ord)
sort panel ord path
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str32 c2 str32 c3 str32 c4 str32 c5 str32 c6 str32 c7 str32 c8 str32 c9 using `display_data', replace
post `DISPLAY' ("Specification") ("Test") ("N") ("Three-way b (SE)") ("p") ("Favored slope b (SE)") ("p") ("Planned contrast Delta (SE)") ("p")
forvalues i=1/`=_N' {
 if panel[`i']==1 & (`i'==1 | panel[`i']!=panel[`i'-1]) {
  post `DISPLAY' ("Panel A. Alternative configuration evaluation values") ("") ("") ("") ("") ("") ("") ("") ("")
 }
 if panel[`i']==2 & (`i'==1 | panel[`i']!=panel[`i'-1]) {
  post `DISPLAY' ("Panel B. Influential-observation exclusions") ("") ("") ("") ("") ("") ("") ("") ("")
 }
 if panel[`i']==3 & (`i'==1 | panel[`i']!=panel[`i'-1]) {
  post `DISPLAY' ("Panel C. Survey-response selection sensitivity") ("") ("") ("") ("") ("") ("") ("") ("")
 }
 local sp=specification[`i']
 local pa=path[`i']
 local ns=trim(string(N[`i'],"%9.0f"))
 if `i'>1 & specification[`i']==specification[`i'-1] & panel[`i']==panel[`i'-1] local sp ""
 local bs = trim(string(triple[`i'],"%9.3f")) + " (" + trim(string(triple_se[`i'],"%9.3f")) + ")"
 local p1 = cond(triple_p[`i']<0.001,"<0.001",trim(string(triple_p[`i'],"%6.3f")))
 local fs = trim(string(favored_slope[`i'],"%9.3f")) + " (" + trim(string(favored_slope_se[`i'],"%9.3f")) + ")"
 local p2 = cond(favored_slope_p[`i']<0.001,"<0.001",trim(string(favored_slope_p[`i'],"%6.3f")))
 local cs = trim(string(planned_contrast[`i'],"%9.3f")) + " (" + trim(string(planned_contrast_se[`i'],"%9.3f")) + ")"
 local p3 = cond(planned_contrast_p[`i']<0.001,"<0.001",trim(string(planned_contrast_p[`i'],"%6.3f")))
 post `DISPLAY' ("`sp'") ("`pa'") ("`ns'") ("`bs'") ("`p1'") ("`fs'") ("`p2'") ("`cs'") ("`p3'")
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",8.5)
putdocx paragraph
putdocx text ("Table H3. Configuration Values, Sample Exclusions, and Survey Selection"), bold
local nr = _N
putdocx table h3 = data("c1 c2 c3 c4 c5 c6 c7 c8 c9"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(1)
putdocx table h3(.,.), font("Arial",8.5) valign(center)
putdocx table h3(1/1,.), bold halign(center)
putdocx table h3(2/`nr',1), halign(left)
putdocx table h3(2/`nr',2/9), halign(center)
putdocx table h3(2,1), colspan(9)
putdocx table h3(2,.), bold
putdocx table h3(7,1), colspan(9)
putdocx table h3(7,.), bold
putdocx table h3(12,1), colspan(9)
putdocx table h3(12,.), bold
putdocx save "$ROOT/outputs/tables/Table_H3.docx", replace
