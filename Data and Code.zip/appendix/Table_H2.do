version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"
* Table H2

tempfile numeric_results
local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock ///
    direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability ///
    i.ownership_n i.industry_n i.province_n

use "$ROOT/data/empirical_analysis.dta", clear

tempname E3
postfile `E3' str48 specification str4 path double N triple triple_se triple_p ///
    favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p ///
    using "`numeric_results'", replace

foreach localm in local_clustering network_constraint {
    local loclab = cond("`localm'"=="local_clustering","Local clustering","Network constraint")
    foreach centm in degree_centrality betweenness_centrality network_centrality_raw pagerank {
        if ("`localm'"=="local_clustering" & "`centm'"=="network_centrality_raw") continue
        local centlab = cond("`centm'"=="degree_centrality","Degree centrality", ///
            cond("`centm'"=="betweenness_centrality","Betweenness centrality", ///
            cond("`centm'"=="network_centrality_raw","Eigenvector centrality","PageRank")))
        local spec "`loclab' x `centlab'"

        capture drop m1_alt_c m2_alt_c
        quietly summarize `localm', meanonly
        generate double m1_alt_c = `localm' - r(mean)
        quietly summarize `centm', meanonly
        generate double m2_alt_c = `centm' - r(mean)
        _pctile m1_alt_c, p(25 75)
        local ml=r(r1)
        local mh=r(r2)
        _pctile m2_alt_c, p(25 75)
        local nl=r(r1)
        local nh=r(r2)

        quietly reg incremental_innovation c.information_complementarity_c##c.m1_alt_c##c.m2_alt_c ///
            capability_complementarity_c `C', vce(hc3)
        local b = _b[c.information_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local s = _se[c.information_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local p = 2*ttail(e(df_r),abs(`b'/`s'))
        quietly lincom _b[information_complementarity_c] + `mh'*_b[c.information_complementarity_c#c.m1_alt_c] + ///
            `nl'*_b[c.information_complementarity_c#c.m2_alt_c] + (`mh'*`nl')*_b[c.information_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local fs=r(estimate)
        local fse=r(se)
        local fp=r(p)
        quietly lincom (`mh'-`ml')*_b[c.information_complementarity_c#c.m1_alt_c] + ///
            (`nl'-`nh')*_b[c.information_complementarity_c#c.m2_alt_c] + ///
            ((`mh'*`nl')-(`ml'*`nh'))*_b[c.information_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        post `E3' ("`spec'") ("H2a") (e(N)) (`b') (`s') (`p') ///
            (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

        quietly reg radical_innovation c.capability_complementarity_c##c.m1_alt_c##c.m2_alt_c ///
            information_complementarity_c `C', vce(hc3)
        local b = _b[c.capability_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local s = _se[c.capability_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local p = 2*ttail(e(df_r),abs(`b'/`s'))
        quietly lincom _b[capability_complementarity_c] + `ml'*_b[c.capability_complementarity_c#c.m1_alt_c] + ///
            `nh'*_b[c.capability_complementarity_c#c.m2_alt_c] + (`ml'*`nh')*_b[c.capability_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        local fs=r(estimate)
        local fse=r(se)
        local fp=r(p)
        quietly lincom (`ml'-`mh')*_b[c.capability_complementarity_c#c.m1_alt_c] + ///
            (`nh'-`nl')*_b[c.capability_complementarity_c#c.m2_alt_c] + ///
            ((`ml'*`nh')-(`mh'*`nl'))*_b[c.capability_complementarity_c#c.m1_alt_c#c.m2_alt_c]
        post `E3' ("`spec'") ("H2b") (e(N)) (`b') (`s') (`p') ///
            (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
    }
}
postclose `E3'
use "`numeric_results'", clear
assert _N==14
assert inlist(path,"H2a","H2b")
assert !missing(N,triple,triple_se,triple_p,favored_slope,favored_slope_se,favored_slope_p,planned_contrast,planned_contrast_se,planned_contrast_p)
order specification path N triple triple_se triple_p favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p
sort specification path

capture restore, not
generate byte ord=.
replace ord=1 if specification=="Local clustering x Degree centrality"
replace ord=2 if specification=="Local clustering x Betweenness centrality"
replace ord=3 if specification=="Local clustering x PageRank"
replace ord=4 if specification=="Network constraint x Degree centrality"
replace ord=5 if specification=="Network constraint x Betweenness centrality"
replace ord=6 if specification=="Network constraint x Eigenvector centrality"
replace ord=7 if specification=="Network constraint x PageRank"
assert !missing(ord)
sort ord path
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str110 c2 str110 c3 str110 c4 str110 c5 str110 c6 str110 c7 str110 c8 str110 c9 using `display_data', replace
post `DISPLAY' ("Specification") ("Test") ("N") ("Three-way b (SE)") ("p") ("Favored slope b (SE)") ("p") ("Planned contrast Delta (SE)") ("p")
forvalues i=1/`=_N' {
 local sp=specification[`i']
 local pa=path[`i']
 local ns=trim(string(N[`i'],"%9.0f"))
 local bs = trim(string(triple[`i'],"%15.3f")) + " (" + trim(string(triple_se[`i'],"%15.3f")) + ")"
 local p1 = cond(triple_p[`i']<0.001,"<0.001",trim(string(triple_p[`i'],"%6.3f")))
 local fs = trim(string(favored_slope[`i'],"%15.3f")) + " (" + trim(string(favored_slope_se[`i'],"%15.3f")) + ")"
 local p2 = cond(favored_slope_p[`i']<0.001,"<0.001",trim(string(favored_slope_p[`i'],"%6.3f")))
 local cs = trim(string(planned_contrast[`i'],"%15.3f")) + " (" + trim(string(planned_contrast_se[`i'],"%15.3f")) + ")"
 local p3 = cond(planned_contrast_p[`i']<0.001,"<0.001",trim(string(planned_contrast_p[`i'],"%6.3f")))
 post `DISPLAY' ("`sp'") ("`pa'") ("`ns'") ("`bs'") ("`p1'") ("`fs'") ("`p2'") ("`cs'") ("`p3'")
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",8.5)
putdocx paragraph
putdocx text ("Table H2. Alternative Network Measures"), bold
local nr = _N
putdocx table h2 = data("c1 c2 c3 c4 c5 c6 c7 c8 c9"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(1)
putdocx table h2(.,.), font("Arial",8.5) valign(center)
putdocx table h2(1/1,.), bold halign(center)
putdocx table h2(2/`nr',1), halign(left)
putdocx table h2(2/`nr',2/9), halign(center)

forvalues row=1/`nr' {
 putdocx table h2(`row',.), nosplit
}
putdocx save "$ROOT/outputs/tables/Table_H2.docx", replace
