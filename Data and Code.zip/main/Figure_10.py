# Figure 10
from pathlib import Path
import os
from matplotlib import font_manager
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

ANALYSIS_FILE = DATA / "empirical_analysis.dta"
EDGE_FILE = DATA / "network_edges.dta"

NETWORK_RADIUS = 2
LAYOUT_SEED = 20260818

ROLE_NAMES = {
    1: "Peripheral Participant",
    2: "Embedded Refiner",
    3: "Network Explorer",
    4: "Integrative Coordinator",
}

def configure_arial():

    candidates = []
    windir = os.environ.get("WINDIR")
    if windir:
        candidates.append(Path(windir) / "Fonts" / "arial.ttf")
    candidates.extend([
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("/Library/Fonts/Arial.ttf"),
        Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
        Path.home() / "Library/Fonts/Arial.ttf",
    ])
    for candidate in candidates:
        if candidate.is_file():
            prop = font_manager.FontProperties(fname=str(candidate))
            if prop.get_name() == "Arial":
                font_manager.fontManager.addfont(str(candidate))
                break
    try:
        resolved = font_manager.findfont(
            font_manager.FontProperties(family="Arial"),
            fallback_to_default=False,
        )
        if font_manager.FontProperties(fname=resolved).get_name() != "Arial":
            raise ValueError("Resolved font is not Arial.")
    except (ValueError, RuntimeError) as exc:
        raise RuntimeError(
            "Genuine Arial is required. Install Arial, or on Windows provide "
            "C:/Windows/Fonts/arial.ttf, then rerun this script."
        ) from exc
    plt.rcParams.update({
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.size": 14.0,
        "font.weight": "normal",
        "axes.labelweight": "normal",
        "axes.titleweight": "normal",
        "savefig.facecolor": "white",
    })
    return "Arial"


ACTIVE_FONT = configure_arial()
plt.rcParams["axes.linewidth"] = 1.0

def load_data():
    df = pd.read_stata(ANALYSIS_FILE, convert_categoricals=False)
    edges = pd.read_stata(EDGE_FILE, convert_categoricals=False)

    required = [
        "firm_id", "network_node_id",
        "ego_network_density", "network_centrality",
        "information_complementarity", "capability_complementarity",
        "information_complementarity_c", "capability_complementarity_c",
        "ego_network_density_c", "network_centrality_c",
        "incremental_innovation", "radical_innovation",
        "firm_size", "firm_age",
        "prior_patent_count", "prior_invention_count",
        "prior_ai_genai_count", "direct_partners_log",
        "genai_use_intensity", "genai_adoption_maturity",
        "digital_capability", "ownership", "industry_code", "province",
    ]
    missing = [v for v in required if v not in df.columns]
    if missing:
        raise ValueError(f"Missing required variables: {missing}")

    df["prior_innovation_stock"] = np.log1p(df["prior_patent_count"])
    df["prior_invention_stock"] = np.log1p(df["prior_invention_count"])
    df["prior_ai_genai_patent_stock"] = np.log1p(df["prior_ai_genai_count"])

    return df, edges

def classify_roles_and_select_representatives(df, G):

    d = df.copy()

    md = d["ego_network_density"].median()
    mc = d["network_centrality"].median()

    d["role"] = np.select(
        [
            (d["ego_network_density"] < md) & (d["network_centrality"] < mc),
            (d["ego_network_density"] >= md) & (d["network_centrality"] < mc),
            (d["ego_network_density"] < md) & (d["network_centrality"] >= mc),
            (d["ego_network_density"] >= md) & (d["network_centrality"] >= mc),
        ],
        [1, 2, 3, 4],
        default=np.nan,
    )

    for raw, zname in [
        ("ego_network_density", "z_density"),
        ("network_centrality", "z_centrality"),
    ]:
        sd = d[raw].std(ddof=1)
        if pd.isna(sd) or sd <= 0:
            d[zname] = 0.0
        else:
            d[zname] = (d[raw] - d[raw].mean()) / sd

    degree_map = dict(G.degree())
    d["struct_degree"] = (
        d["network_node_id"]
        .astype(int)
        .map(degree_map)
        .fillna(0)
        .astype(int)
    )

    d["centroid_distance"] = np.nan
    d["representative_candidate"] = 0

    selected_rows = []

    for role in [1, 2, 3, 4]:
        idx = d.index[d["role"] == role]

        centroid_density = d.loc[idx, "z_density"].mean()
        centroid_centrality = d.loc[idx, "z_centrality"].mean()

        distances = np.sqrt(
            (d.loc[idx, "z_density"] - centroid_density) ** 2
            + (d.loc[idx, "z_centrality"] - centroid_centrality) ** 2
        )

        d.loc[idx, "centroid_distance"] = distances

        n_keep = max(1, int(np.ceil(len(idx) * 0.50)))

        candidate_idx = (
            d.loc[idx]
            .sort_values(
                ["centroid_distance", "firm_id"],
                ascending=[True, True],
            )
            .head(n_keep)
            .index
        )

        d.loc[candidate_idx, "representative_candidate"] = 1

        chosen = (
            d.loc[candidate_idx]
            .sort_values(
                ["struct_degree", "centroid_distance", "firm_id"],
                ascending=[False, True, True],
            )
            .iloc[0]
        )

        selected_rows.append(chosen)

    reps = pd.DataFrame(selected_rows).sort_values("role").reset_index(drop=True)

    return d, reps, md, mc

FORMULA_M4 = """
incremental_innovation ~
information_complementarity_c * ego_network_density_c * network_centrality_c
+ capability_complementarity_c
+ firm_size
+ firm_age
+ prior_innovation_stock
+ prior_invention_stock
+ prior_ai_genai_patent_stock
+ direct_partners_log
+ genai_use_intensity
+ genai_adoption_maturity
+ digital_capability
+ C(ownership)
+ C(industry_code)
+ C(province)
"""

FORMULA_M8 = """
radical_innovation ~
capability_complementarity_c * ego_network_density_c * network_centrality_c
+ information_complementarity_c
+ firm_size
+ firm_age
+ prior_innovation_stock
+ prior_invention_stock
+ prior_ai_genai_patent_stock
+ direct_partners_log
+ genai_use_intensity
+ genai_adoption_maturity
+ digital_capability
+ C(ownership)
+ C(industry_code)
+ C(province)
"""

def fit_models(df):
    m4 = smf.ols(FORMULA_M4, data=df).fit(cov_type="HC3")
    m8 = smf.ols(FORMULA_M8, data=df).fit(cov_type="HC3")
    return m4, m8

def make_prediction_table(df, reps, m4, m8):

    ic_low, ic_high = df["information_complementarity"].quantile([0.25, 0.75])
    cc_low, cc_high = df["capability_complementarity"].quantile([0.25, 0.75])

    means = {
        "ic": df["information_complementarity"].mean(),
        "cc": df["capability_complementarity"].mean(),
        "d": df["ego_network_density"].mean(),
        "c": df["network_centrality"].mean(),
    }

    inc_mean = df["incremental_innovation"].mean()
    inc_sd = df["incremental_innovation"].std(ddof=1)
    rad_mean = df["radical_innovation"].mean()
    rad_sd = df["radical_innovation"].std(ddof=1)

    records = []

    for _, rep in reps.iterrows():
        role = int(rep["role"])

        for level, raw_value in [("Low", ic_low), ("High", ic_high)]:
            nd = df.copy()
            nd["information_complementarity_c"] = raw_value - means["ic"]
            nd["ego_network_density_c"] = rep["ego_network_density"] - means["d"]
            nd["network_centrality_c"] = rep["network_centrality"] - means["c"]

            avg_pred = float(np.mean(m4.predict(nd)))
            pred_z = (avg_pred - inc_mean) / inc_sd

            records.append({
                "role": role,
                "role_name": ROLE_NAMES[role],
                "firm_id": rep["firm_id"],
                "pathway": "Information complementarity–incremental innovation",
                "level": level,
                "complementarity_value": raw_value,
                "predicted_raw": avg_pred,
                "predicted_standardized": pred_z,
            })

        for level, raw_value in [("Low", cc_low), ("High", cc_high)]:
            nd = df.copy()
            nd["capability_complementarity_c"] = raw_value - means["cc"]
            nd["ego_network_density_c"] = rep["ego_network_density"] - means["d"]
            nd["network_centrality_c"] = rep["network_centrality"] - means["c"]

            avg_pred = float(np.mean(m8.predict(nd)))
            pred_z = (avg_pred - rad_mean) / rad_sd

            records.append({
                "role": role,
                "role_name": ROLE_NAMES[role],
                "firm_id": rep["firm_id"],
                "pathway": "Capability complementarity–radical innovation",
                "level": level,
                "complementarity_value": raw_value,
                "predicted_raw": avg_pred,
                "predicted_standardized": pred_z,
            })

    return pd.DataFrame(records)

def build_graph(edges):
    return nx.from_pandas_edgelist(
        edges,
        source="node_u",
        target="node_v",
        create_using=nx.Graph(),
    )

def local_network(
    G,
    focal_node,
    focal_centrality,
    radius=NETWORK_RADIUS,
):

    focal_node = int(focal_node)

    if focal_node not in G:
        raise ValueError(f"Network node {focal_node} not found.")

    first_tier = set(G.neighbors(focal_node))
    core_nodes = {focal_node} | first_tier

    dist = nx.single_source_shortest_path_length(
        G,
        focal_node,
        cutoff=max(2, int(radius)),
    )

    second_tier = {
        node for node, dd in dist.items()
        if dd == 2
    }

    reach_cap = int(
        np.clip(
            np.round(18 + 105 * float(focal_centrality)),
            20,
            125,
        )
    )

    scored = []

    for node in second_tier:
        ties_to_first = sum(
            1
            for nbr in G.neighbors(node)
            if nbr in first_tier
        )

        scored.append(
            (
                node,
                ties_to_first,
                G.degree(node),
            )
        )

    scored.sort(
        key=lambda x: (
            -x[1],
            -x[2],
            x[0],
        )
    )

    reach_nodes = {
        node
        for node, _, _ in scored[:reach_cap]
    }

    keep = core_nodes | reach_nodes
    H = G.subgraph(keep).copy()

    nx.set_node_attributes(
        H,
        {
            node: (
                "core"
                if node in core_nodes
                else "reach"
            )
            for node in H.nodes()
        },
        "layer",
    )


    return H

def draw_network_inset(fig, H, role, rect=(0.70, 0.69, 0.24, 0.24)):

    inset = fig.add_axes(rect)

    n = H.number_of_nodes()

    core_nodes = [
        node
        for node, attrs in H.nodes(data=True)
        if attrs.get("layer") == "core"
    ]

    reach_nodes = [
        node
        for node, attrs in H.nodes(data=True)
        if attrs.get("layer") == "reach"
    ]

    core_set = set(core_nodes)

    rng = np.random.default_rng(
        LAYOUT_SEED + int(role)
    )

    initial = {}

    for node in core_nodes:
        angle = rng.uniform(0, 2 * np.pi)
        radius = 0.06 + 0.25 * rng.beta(1.8, 3.4)

        initial[node] = np.array(
            [
                radius * np.cos(angle),
                radius * np.sin(angle),
            ]
        )

    for node in reach_nodes:
        angle = rng.uniform(0, 2 * np.pi)
        radius = 0.55 + 0.55 * rng.beta(2.0, 1.7)

        initial[node] = np.array(
            [
                radius * np.cos(angle),
                radius * np.sin(angle),
            ]
        )

    try:
        pos = nx.forceatlas2_layout(
            H,
            pos=initial,
            max_iter=1900,
            jitter_tolerance=0.82,
            scaling_ratio=2.70,
            gravity=0.52,
            distributed_action=False,
            strong_gravity=False,
            weight=None,
            linlog=False,
            seed=LAYOUT_SEED + int(role),
        )

    except Exception:
        pos = nx.spring_layout(
            H,
            pos=initial,
            seed=LAYOUT_SEED + int(role),
            iterations=1500,
            k=0.90 / np.sqrt(max(n, 2)),
            weight=None,
        )

    coords = np.array(list(pos.values()), dtype=float)
    center = coords.mean(axis=0)

    if role in (2, 4):
        core_factor = 0.58
    else:
        core_factor = 0.78

    if role in (3, 4):
        reach_factor = 1.16
    else:
        reach_factor = 0.96

    for node in core_nodes:
        vec = np.array(pos[node]) - center
        pos[node] = center + core_factor * vec

    for node in reach_nodes:
        vec = np.array(pos[node]) - center
        pos[node] = center + reach_factor * vec

    core_edges = []
    reach_edges = []

    for u, v in H.edges():
        if u in core_set and v in core_set:
            core_edges.append((u, v))
        else:
            reach_edges.append((u, v))

    nx.draw_networkx_edges(
        H,
        pos,
        edgelist=list(H.edges()),
        ax=inset,
        edge_color="0.55",
        width=1.10,
        alpha=0.020,
    )

    nx.draw_networkx_edges(
        H,
        pos,
        edgelist=reach_edges,
        ax=inset,
        edge_color="0.40",
        width=0.48,
        alpha=0.22,
    )

    nx.draw_networkx_edges(
        H,
        pos,
        edgelist=core_edges,
        ax=inset,
        edge_color="0.05",
        width=0.70,
        alpha=0.42,
    )

    uniform_node_size = 6.0

    all_nodes = list(H.nodes())

    nx.draw_networkx_nodes(
        H,
        pos,
        nodelist=all_nodes,
        ax=inset,
        node_size=uniform_node_size * 1.75,
        node_color="0.55",
        edgecolors="none",
        alpha=0.05,
    )

    nx.draw_networkx_nodes(
        H,
        pos,
        nodelist=all_nodes,
        ax=inset,
        node_size=uniform_node_size,
        node_color="0.02",
        edgecolors="none",
        alpha=0.96,
    )

    inset.set_xticks([])
    inset.set_yticks([])
    inset.set_facecolor("white")

    for spine in inset.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.05)
        spine.set_color("black")

    try:
        inset.set_box_aspect(1)
    except Exception:
        inset.set_aspect(
            "equal",
            adjustable="box",
        )

    xs = np.array(
        [xy[0] for xy in pos.values()],
        dtype=float,
    )

    ys = np.array(
        [xy[1] for xy in pos.values()],
        dtype=float,
    )

    if len(xs):
        xmin, xmax = xs.min(), xs.max()
        ymin, ymax = ys.min(), ys.max()

        xr = max(xmax - xmin, 1e-8)
        yr = max(ymax - ymin, 1e-8)

        inset.set_xlim(
            xmin - 0.04 * xr,
            xmax + 0.04 * xr,
        )

        inset.set_ylim(
            ymin - 0.04 * yr,
            ymax + 0.04 * yr,
        )


def plot_figure10(reps, pred, edges):

    G = build_graph(edges)

    pmin = pred["predicted_standardized"].min()
    pmax = pred["predicted_standardized"].max()

    lower = min(-0.32, np.floor((pmin - 0.03) * 20) / 20)
    upper = max(0.66, np.ceil((pmax + 0.08) * 20) / 20)

    x = np.array([0.0, 1.0])

    role_stems = {
        1: "a_Peripheral_Participant",
        2: "b_Embedded_Refiner",
        3: "c_Network_Explorer",
        4: "d_Integrative_Coordinator",
    }

    for role in [1, 2, 3, 4]:
        rep = reps.loc[reps["role"] == role].iloc[0]
        sub = pred.loc[pred["role"] == role].copy()

        ic = (
            sub[sub["pathway"].str.startswith("Information")]
            .set_index("level")
            .loc[["Low", "High"]]
        )
        cc = (
            sub[sub["pathway"].str.startswith("Capability")]
            .set_index("level")
            .loc[["Low", "High"]]
        )

        y_ic = ic["predicted_standardized"].to_numpy()
        y_cc = cc["predicted_standardized"].to_numpy()

        fig = plt.figure(figsize=(5.85, 4.95))

        ax = fig.add_axes([0.14, 0.245, 0.68, 0.425])

        fig.text(
            0.14, 0.755,
            f'{ROLE_NAMES[role]} (Firm ID: {rep["firm_id"]})',
            ha="left", va="center",
            fontsize=12.0,
            fontweight="normal",
            fontfamily=ACTIVE_FONT,
        )

        fig.text(
            0.14, 0.708,
            (
                f'Density = {rep["ego_network_density"]:.3f}    '
                f'Centrality = {rep["network_centrality"]:.3f}'
            ),
            ha="left", va="center",
            fontsize=12.6,
            fontweight="normal",
            fontfamily=ACTIVE_FONT,
        )

        ax.plot(
            x, y_ic,
            color="black",
            linewidth=1.55,
            linestyle="-",
            marker="o",
            markersize=6.8,
            markerfacecolor="black",
            markeredgecolor="black",
            zorder=4,
            label="Information complementarity–incremental innovation",
        )

        ax.plot(
            x, y_cc,
            color="black",
            linewidth=1.45,
            linestyle=(0, (4, 2.5)),
            marker="s",
            markersize=6.4,
            markerfacecolor="white",
            markeredgecolor="black",
            markeredgewidth=1.1,
            zorder=4,
            label="Capability complementarity–radical innovation",
        )

        ax.axhline(
            0,
            color="black",
            linewidth=0.85,
            linestyle=(0, (2.4, 2.4)),
            zorder=1,
        )

        H = local_network(
            G,
            int(rep["network_node_id"]),
            focal_centrality=float(rep["network_centrality"]),
            radius=NETWORK_RADIUS,
        )

        draw_network_inset(
            fig,
            H,
            role,
            rect=(0.655, 0.590, 0.205, 0.205),
        )

        ax.set_xlim(-0.22, 1.22)
        ax.set_ylim(lower, upper)

        ax.set_xticks([0, 1])
        ax.set_xticklabels(
            ["Low", "High"],
            fontsize=13.0,
            fontfamily=ACTIVE_FONT,
            fontweight="normal",
        )

        ax.set_xlabel(
            "Complementarity Level",
            fontsize=13.4,
            labelpad=7,
            fontfamily=ACTIVE_FONT,
            fontweight="normal",
        )

        ax.set_ylabel(
            "Predicted Innovation Outcomes",
            fontsize=13.4,
            labelpad=9,
            fontfamily=ACTIVE_FONT,
            fontweight="normal",
        )

        ax.tick_params(
            axis="both",
            labelsize=12.8,
            width=0.9,
            length=4.2,
            direction="out",
        )

        for tick in ax.get_xticklabels() + ax.get_yticklabels():
            tick.set_fontfamily(ACTIVE_FONT)
            tick.set_fontweight("normal")

        xtlabs = ax.get_xticklabels()
        if len(xtlabs) >= 2:
            xtlabs[0].set_ha("center")
            xtlabs[1].set_ha("right")
            xtlabs[1].set_x(0.97)

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        ax.spines["left"].set_bounds(lower, 0.6)

        handles, labels = ax.get_legend_handles_labels()

        leg = fig.legend(
            handles,
            labels,
            loc="lower center",
            bbox_to_anchor=(0.48, -0.008),
            ncol=1,
            frameon=True,
            fancybox=False,
            edgecolor="black",
            facecolor="white",
            framealpha=1.0,
            fontsize=10.4,
            handlelength=2.25,
            borderaxespad=0.0,
            labelspacing=0.34,
            borderpad=0.42,
        )
        leg.get_frame().set_linewidth(0.8)

        for txt in leg.get_texts():
            txt.set_fontfamily(ACTIVE_FONT)
            txt.set_fontweight("normal")

        stem = f"Figure_10_{role_stems[role]}"

        fig.savefig(
            OUT / f"{stem}.png",
            bbox_inches="tight",
            dpi=600,
        )

        plt.close(fig)

def make_figure10():
    df, edges = load_data()
    G = build_graph(edges)
    _, reps, density_median, centrality_median = (
        classify_roles_and_select_representatives(df, G)
    )
    m4, m8 = fit_models(df)
    pred = make_prediction_table(df, reps, m4, m8)

    rep_export = reps[
        [
            "role",
            "firm_id",
            "network_node_id",
            "ego_network_density",
            "network_centrality",
            "struct_degree",
            "centroid_distance",
            "representative_candidate",
        ]
    ].copy()
    rep_export["role_name"] = rep_export["role"].map(ROLE_NAMES)
    plot_figure10(reps, pred, edges)

    print(f"Figure 10 created successfully using {ACTIVE_FONT}.")
    print(f"Density median: {density_median:.6f}")
    print(f"Centrality median: {centrality_median:.6f}")
    print("\nRepresentative firms:")
    print(
        rep_export[
            ["role", "role_name", "firm_id",
             "ego_network_density", "network_centrality"]
        ].to_string(index=False)
    )
    print("\nOutputs:")
    for stem in ['Figure_10_a_Peripheral_Participant', 'Figure_10_b_Embedded_Refiner', 'Figure_10_c_Network_Explorer', 'Figure_10_d_Integrative_Coordinator']:
        print(OUT / f"{stem}.png")

if __name__ == "__main__":
    make_figure10()
