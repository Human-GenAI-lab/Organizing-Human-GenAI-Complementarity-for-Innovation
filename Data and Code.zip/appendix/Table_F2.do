version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/survey_items.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table F2
local CONSTRUCTS IC CC GUI GAM DC
local IC_items IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10
local CC_items CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10
local GUI_items GUI1 GUI2 GUI3 GUI4
local GAM_items GAM1 GAM2 GAM3 GAM4
local DC_items DC1 DC2 DC3 DC4
local IC_name "Information complementarity"
local CC_name "Capability complementarity"
local GUI_name "GenAI use intensity"
local GAM_name "GenAI adoption maturity"
local DC_name "Digital capability"
tempfile item_results

use "$ROOT/data/survey_items.dta", clear
assert _N == 312

foreach c of local CONSTRUCTS {
    local thisitems "``c'_items'"
    quietly alpha `thisitems'
    scalar ALPHA_`c' = r(alpha)
}

sem (IC -> `IC_items') ///
    (CC -> `CC_items') ///
    (GUI -> `GUI_items') ///
    (GAM -> `GAM_items') ///
    (DC -> `DC_items'), ///
    latent(IC CC GUI GAM DC) nocapslatent method(mlmv)

quietly estat framework, standardized
matrix G = r(Gamma)

tempname RVAL
postfile `RVAL' str40 construct str8 item double loading alpha cr ave ///
    using `item_results', replace
foreach c of local CONSTRUCTS {
    local thisitems "``c'_items'"
    local thisname "``c'_name'"
    local nitems : word count `thisitems'
    scalar SL = 0
    scalar SL2 = 0
    foreach it of local thisitems {
        scalar LL = G[rownumb(G,"`it'"),colnumb(G,"`c'")]
        scalar SL = SL + LL
        scalar SL2 = SL2 + LL^2
    }
    scalar CR = SL^2 / (SL^2 + `nitems' - SL2)
    scalar AVE = SL2 / `nitems'
    foreach it of local thisitems {
        scalar LL = G[rownumb(G,"`it'"),colnumb(G,"`c'")]
        post `RVAL' ("`thisname'") ("`it'") ///
            (LL) (ALPHA_`c') (CR) (AVE)
    }
}
postclose `RVAL'

use `item_results', clear
assert _N == 32
assert !missing(loading,alpha,cr,ave)

capture putdocx clear

putdocx begin, pagesize(A4) font("Arial",9)
putdocx paragraph
putdocx text ("Table F2. Item Loadings, Reliability, and Convergent Validity"), bold font("Arial",10.5)

local nr = _N + 1
putdocx table f2 = (`nr',6), ///
    border(all,single,D9D9D9) layout(autofitwindow) headerrow(1) ///
    cellmargin(top,1pt) cellmargin(bottom,1pt)
putdocx table f2(1,1) = ("Construct")
putdocx table f2(1,2) = ("Item")
putdocx table f2(1,3) = ("CFA loading")
putdocx table f2(1,4) = ("Alpha")
putdocx table f2(1,5) = ("CR")
putdocx table f2(1,6) = ("AVE")
forvalues i=1/`=_N' {
    local r = `i' + 1
    local loading_text = trim(string(loading[`i'],"%6.3f"))
    putdocx table f2(`r',2) = (item[`i'])
    putdocx table f2(`r',3) = ("`loading_text'")
}
local first = 1
foreach c of local CONSTRUCTS {
    local thisitems "``c'_items'"
    local nitems : word count `thisitems'
    local r = `first' + 1
    local alpha_text = trim(string(alpha[`first'],"%6.3f"))
    local cr_text = trim(string(cr[`first'],"%6.3f"))
    local ave_text = trim(string(ave[`first'],"%6.3f"))
    putdocx table f2(`r',1) = (construct[`first'])
    putdocx table f2(`r',4) = ("`alpha_text'")
    putdocx table f2(`r',5) = ("`cr_text'")
    putdocx table f2(`r',6) = ("`ave_text'")
    local first = `first' + `nitems'
}
putdocx table f2(.,.), font("Arial",9) valign(center)
putdocx table f2(.,2/6), halign(center)
putdocx table f2(1,.), bold halign(center) shading(F2F2F2) ///
    border(top,single,000000) border(bottom,single,000000)

local first = 1
foreach c of local CONSTRUCTS {
    local thisitems "``c'_items'"
    local nitems : word count `thisitems'
    local r = `first' + 1
    foreach j in 1 4 5 6 {
        putdocx table f2(`r',`j'), rowspan(`nitems')
    }
    local first = `first' + `nitems'
}

putdocx save "$ROOT/outputs/tables/Table_F2.docx", replace
