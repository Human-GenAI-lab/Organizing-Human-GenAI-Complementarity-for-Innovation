version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"
* Table H1
tempfile numeric_results
use "$ROOT/data/empirical_analysis.dta", clear

local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock ///
    direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability ///
    i.ownership_n i.industry_n i.province_n

_pctile ego_network_density_c, p(25 75)
local dl = r(r1)
local dh = r(r2)
_pctile network_centrality_c, p(25 75)
local cl = r(r1)
local ch = r(r2)

tempname E1
postfile `E1' str20 estimator str4 path str28 outcome double N triple triple_se triple_p ///
    favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p ///
    using "`numeric_results'", replace

quietly poisson incremental_patent_count ///
    c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
    capability_complementarity_c `C', vce(robust)
local b = _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s = _se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p = 2*normal(-abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dh'*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
    `cl'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dh'*`cl')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dh'-`dl')*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
    (`cl'-`ch')*_b[c.information_complementarity_c#c.network_centrality_c] + ///
    ((`dh'*`cl')-(`dl'*`ch'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E1' ("Poisson") ("H2a") ("Incremental patent count") (e(N)) (`b') (`s') (`p') ///
    (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly poisson radical_invention_count ///
    c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
    information_complementarity_c `C', vce(robust)
local b = _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s = _se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p = 2*normal(-abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dl'*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
    `ch'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dl'*`ch')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dl'-`dh')*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
    (`ch'-`cl')*_b[c.capability_complementarity_c#c.network_centrality_c] + ///
    ((`dl'*`ch')-(`dh'*`cl'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E1' ("Poisson") ("H2b") ("Radical invention count") (e(N)) (`b') (`s') (`p') ///
    (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly nbreg incremental_patent_count ///
    c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
    capability_complementarity_c `C', vce(robust)
local b = _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s = _se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p = 2*normal(-abs(`b'/`s'))
quietly lincom _b[information_complementarity_c] + `dh'*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
    `cl'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dh'*`cl')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dh'-`dl')*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
    (`cl'-`ch')*_b[c.information_complementarity_c#c.network_centrality_c] + ///
    ((`dh'*`cl')-(`dl'*`ch'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E1' ("Negative binomial") ("H2a") ("Incremental patent count") (e(N)) (`b') (`s') (`p') ///
    (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))

quietly nbreg radical_invention_count ///
    c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
    information_complementarity_c `C', vce(robust)
local b = _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local s = _se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local p = 2*normal(-abs(`b'/`s'))
quietly lincom _b[capability_complementarity_c] + `dl'*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
    `ch'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dl'*`ch')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local fs=r(estimate)
local fse=r(se)
local fp=r(p)
quietly lincom (`dl'-`dh')*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
    (`ch'-`cl')*_b[c.capability_complementarity_c#c.network_centrality_c] + ///
    ((`dl'*`ch')-(`dh'*`cl'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
post `E1' ("Negative binomial") ("H2b") ("Radical invention count") (e(N)) (`b') (`s') (`p') ///
    (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
postclose `E1'
use "`numeric_results'", clear
assert _N==4
assert inlist(path,"H2a","H2b")
assert !missing(N,triple,triple_se,triple_p,favored_slope,favored_slope_se,favored_slope_p,planned_contrast,planned_contrast_se,planned_contrast_p)
order estimator path outcome N triple triple_se triple_p favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p
sort estimator path

capture restore, not
tempfile count_estimates
save `count_estimates', replace

tempfile numeric_results
local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock ///
    direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability ///
    i.ownership_n i.industry_n i.province_n

use "$ROOT/data/empirical_analysis.dta", clear
generate double incremental_invention_alt = ln(1 + incremental_invention_count)
generate double radical_novel_combo_alt = ln(1 + radical_novel_combo_count)

_pctile ego_network_density_c, p(25 75)
local dl = r(r1)
local dh = r(r2)
_pctile network_centrality_c, p(25 75)
local cl = r(r1)
local ch = r(r2)

tempname E2
postfile `E2' str44 specification str4 path str28 outcome double N triple triple_se triple_p ///
    favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p ///
    using "`numeric_results'", replace

foreach y in incremental_invention_alt {
    local spec "Invention patents within prior domains"
    quietly reg `y' c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
        capability_complementarity_c `C', vce(hc3)
    local b = _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local s = _se[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local p = 2*ttail(e(df_r),abs(`b'/`s'))
    quietly lincom _b[information_complementarity_c] + `dh'*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
        `cl'*_b[c.information_complementarity_c#c.network_centrality_c] + (`dh'*`cl')*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local fs=r(estimate)
    local fse=r(se)
    local fp=r(p)
    quietly lincom (`dh'-`dl')*_b[c.information_complementarity_c#c.ego_network_density_c] + ///
        (`cl'-`ch')*_b[c.information_complementarity_c#c.network_centrality_c] + ///
        ((`dh'*`cl')-(`dl'*`ch'))*_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    post `E2' ("`spec'") ("H2a") ("`y'") (e(N)) (`b') (`s') (`p') ///
        (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
}

foreach y in radical_novel_combo_alt radicalness_index {
    local spec = cond("`y'"=="radical_novel_combo_alt","Patents with novel IPC combinations","Continuous radicalness index")

    quietly reg `y' c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
        information_complementarity_c `C', vce(hc3)
    local b = _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local s = _se[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local p = 2*ttail(e(df_r),abs(`b'/`s'))
    quietly lincom _b[capability_complementarity_c] + `dl'*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
        `ch'*_b[c.capability_complementarity_c#c.network_centrality_c] + (`dl'*`ch')*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    local fs=r(estimate)
    local fse=r(se)
    local fp=r(p)
    quietly lincom (`dl'-`dh')*_b[c.capability_complementarity_c#c.ego_network_density_c] + ///
        (`ch'-`cl')*_b[c.capability_complementarity_c#c.network_centrality_c] + ///
        ((`dl'*`ch')-(`dh'*`cl'))*_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
    post `E2' ("`spec'") ("H2b") ("`y'") (e(N)) (`b') (`s') (`p') ///
        (`fs') (`fse') (`fp') (r(estimate)) (r(se)) (r(p))
}
postclose `E2'
use "`numeric_results'", clear
assert _N==3
assert inlist(path,"H2a","H2b")
assert !missing(N,triple,triple_se,triple_p,favored_slope,favored_slope_se,favored_slope_p,planned_contrast,planned_contrast_se,planned_contrast_p)
order specification path outcome N triple triple_se triple_p favored_slope favored_slope_se favored_slope_p planned_contrast planned_contrast_se planned_contrast_p
sort path specification

capture restore, not
tempfile alternative_estimates
save `alternative_estimates', replace
use `count_estimates', clear
rename estimator specification
generate byte panel=1
generate byte ord=cond(specification=="Poisson",1,2)
tempfile count_results
save `count_results', replace
use `alternative_estimates', clear
keep if inlist(outcome,"incremental_invention_alt","radical_novel_combo_alt","radicalness_index")
generate byte panel=2
generate byte ord=.
replace ord=1 if outcome=="incremental_invention_alt"
replace ord=2 if outcome=="radical_novel_combo_alt"
replace ord=3 if outcome=="radicalness_index"
replace specification="Invention patent applications within prior technological domains" if ord==1
replace specification="Novel IPC combinations" if ord==2
replace specification="Continuous radicalness index" if ord==3
append using `count_results'
sort panel ord path
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str32 c2 str32 c3 str32 c4 str32 c5 str32 c6 str32 c7 str32 c8 str32 c9 using `display_data', replace
post `DISPLAY' ("Specification") ("Test") ("N") ("Three-way b (SE)") ("p") ("Favored slope b (SE)") ("p") ("Planned contrast Delta (SE)") ("p")
forvalues i=1/`=_N' {
 if panel[`i']==1 & (`i'==1 | panel[`i']!=panel[`i'-1]) {
  post `DISPLAY' ("Panel A. Count-data estimators") ("") ("") ("") ("") ("") ("") ("") ("")
 }
 if panel[`i']==2 & (`i'==1 | panel[`i']!=panel[`i'-1]) {
  post `DISPLAY' ("Panel B. Alternative innovation measures") ("") ("") ("") ("") ("") ("") ("") ("")
 }
 local sp=specification[`i']
 local pa=path[`i']
 local ns=trim(string(N[`i'],"%9.0f"))
 if `i'>1 & specification[`i']==specification[`i'-1] & panel[`i']==panel[`i'-1] local sp ""
 local bs = trim(string(triple[`i'],"%9.3f")) + " (" + trim(string(triple_se[`i'],"%9.3f")) + ")"
 local p1 = cond(triple_p[`i']<0.001,"<0.001",trim(string(triple_p[`i'],"%6.3f")))
 local fs = trim(string(favored_slope[`i'],"%9.3f")) + " (" + trim(string(favored_slope_se[`i'],"%9.3f")) + ")"
 local p2 = cond(favored_slope_p[`i']<0.001,"<0.001",trim(string(favored_slope_p[`i'],"%6.3f")))
 local cs = trim(string(planned_contrast[`i'],"%9.3f")) + " (" + trim(string(planned_contrast_se[`i'],"%9.3f")) + ")"
 local p3 = cond(planned_contrast_p[`i']<0.001,"<0.001",trim(string(planned_contrast_p[`i'],"%6.3f")))
 post `DISPLAY' ("`sp'") ("`pa'") ("`ns'") ("`bs'") ("`p1'") ("`fs'") ("`p2'") ("`cs'") ("`p3'")
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",8.5)
putdocx paragraph
putdocx text ("Table H1. Alternative Estimators and Innovation Measures"), bold
local nr = _N
putdocx table h1 = data("c1 c2 c3 c4 c5 c6 c7 c8 c9"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(1)
putdocx table h1(.,.), font("Arial",8.5) valign(center)
putdocx table h1(1/1,.), bold halign(center)
putdocx table h1(2/`nr',1), halign(left)
putdocx table h1(2/`nr',2/9), halign(center)
putdocx table h1(2,1), colspan(9)
putdocx table h1(2,.), bold
putdocx table h1(7,1), colspan(9)
putdocx table h1(7,.), bold
putdocx save "$ROOT/outputs/tables/Table_H1.docx", replace
