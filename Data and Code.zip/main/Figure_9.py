# Figure 9
from pathlib import Path
import os
from matplotlib import font_manager
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from itertools import combinations
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "empirical_analysis.dta"
OUT = ROOT / "outputs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

def configure_arial():

    candidates = []
    windir = os.environ.get("WINDIR")
    if windir:
        candidates.append(Path(windir) / "Fonts" / "arial.ttf")
    candidates.extend([
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("/Library/Fonts/Arial.ttf"),
        Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
        Path.home() / "Library/Fonts/Arial.ttf",
    ])
    for candidate in candidates:
        if candidate.is_file():
            prop = font_manager.FontProperties(fname=str(candidate))
            if prop.get_name() == "Arial":
                font_manager.fontManager.addfont(str(candidate))
                break
    try:
        resolved = font_manager.findfont(
            font_manager.FontProperties(family="Arial"),
            fallback_to_default=False,
        )
        if font_manager.FontProperties(fname=resolved).get_name() != "Arial":
            raise ValueError("Resolved font is not Arial.")
    except (ValueError, RuntimeError) as exc:
        raise RuntimeError(
            "Genuine Arial is required. Install Arial, or on Windows provide "
            "C:/Windows/Fonts/arial.ttf, then rerun this script."
        ) from exc
    plt.rcParams.update({
        "font.family": "Arial",
        "font.sans-serif": ["Arial"],
        "font.size": 14.0,
        "font.weight": "normal",
        "axes.labelweight": "normal",
        "axes.titleweight": "normal",
        "savefig.facecolor": "white",
    })
    return "Arial"


ACTIVE_FONT = configure_arial()

plt.rcParams["axes.linewidth"] = 0.90

ROLE_ORDER = [
    "Peripheral Participant",
    "Embedded Refiner",
    "Network Explorer",
    "Integrative Coordinator",
]
SHORT = ["Peripheral\nParticipant", "Embedded\nRefiner", "Network\nExplorer", "Integrative\nCoordinator"]
MARKERS = ["o", "s", "^", "D"]
MFC = ["black", "0.50", "white", "white"]
MEC = ["black", "0.25", "0.25", "0.25"]

GAP = 0.045
MIN_STEM = 0.060
TEXT_GAP = 0.035
TEXT_HEIGHT = 0.045
def p_label(p):
    if p < 0.001:
        return "<0.0010"
    return f"{p:.4f}"

def style_axes(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_bounds(-0.5, 1.0)
    ax.tick_params(axis="y", direction="out", length=5, width=1.0)
    ax.tick_params(axis="x", direction="out", length=5, width=1.0)

def panel_brackets():
    return [(1,2), (3,4), (2,3), (1,3), (2,4), (1,4)]

def fetch_p(pairwise_df, a, b):
    row = pairwise_df[
        ((pairwise_df.role_a == a) & (pairwise_df.role_b == b)) |
        ((pairwise_df.role_a == b) & (pairwise_df.role_b == a))
    ].iloc[0]
    return float(row["p"])

def draw_background_band(ax, ymin=-0.5, ymax=0.0):
    ax.axhspan(ymin, ymax, color="#e9e9e9", zorder=0)

def draw_points(ax, sub):
    x = np.arange(len(sub))
    upper_bounds = []
    for i, row in enumerate(sub.to_dict("records")):
        lower = row["slope"] - row["lb"]
        upper = row["ub"] - row["slope"]
        upper_bounds.append(float(row["ub"]))
        ax.errorbar(
            x[i], row["slope"],
            yerr=[[lower], [upper]],
            fmt=MARKERS[i],
            markersize=6.8,
            color="0.20",
            ecolor="0.20",
            markerfacecolor=MFC[i],
            markeredgecolor=MEC[i],
            markeredgewidth=1.0,
            elinewidth=1.15,
            capsize=3.2,
            capthick=1.15,
            zorder=3,
        )
    return x, np.array(upper_bounds)

def overlaps(a1, a2, b1, b2):
    return not (a2 < b1 or b2 < a1)

def draw_brackets_compact(ax, upper_bounds, pairs, pairwise_df):

    endpoint_anchor = np.array(upper_bounds, dtype=float).copy()

    column_label_top = np.full(len(upper_bounds), -1e9, dtype=float)

    placed = []
    label_specs = []
    highest_text_y = float(np.max(upper_bounds))

    bottom_tier_y = float(np.max(upper_bounds)) + GAP + MIN_STEM

    for a, b in pairs:
        i1, i2 = a - 1, b - 1

        left_anchor = max(endpoint_anchor[i1], column_label_top[i1])
        right_anchor = max(endpoint_anchor[i2], column_label_top[i2])

        left_bottom = left_anchor + GAP
        right_bottom = right_anchor + GAP

        top_y = max(left_bottom, right_bottom) + MIN_STEM
        if (a, b) in ((1, 2), (3, 4)):
            top_y = max(top_y, bottom_tier_y)

        for item in placed:
            if overlaps(i1, i2, item["x1"], item["x2"]):
                top_y = max(top_y, item["label_top"] + GAP + MIN_STEM)

        text_y = top_y + TEXT_GAP
        label_top = text_y + TEXT_HEIGHT

        ax.plot(
            [i1, i1],
            [left_bottom, top_y],
            color="black",
            lw=1.0,
            clip_on=False,
            solid_capstyle="butt",
            zorder=4,
        )
        ax.plot(
            [i1, i2],
            [top_y, top_y],
            color="black",
            lw=1.0,
            clip_on=False,
            solid_capstyle="butt",
            zorder=4,
        )
        ax.plot(
            [i2, i2],
            [top_y, right_bottom],
            color="black",
            lw=1.0,
            clip_on=False,
            solid_capstyle="butt",
            zorder=4,
        )

        center_x = (i1 + i2) / 2.0
        label_specs.append({
            "x": center_x,
            "y": text_y,
            "label": p_label(fetch_p(pairwise_df, a, b)),
        })

        endpoint_anchor[i1] = max(endpoint_anchor[i1], top_y)
        endpoint_anchor[i2] = max(endpoint_anchor[i2], top_y)

        if abs(center_x - round(center_x)) < 1e-9:
            c = int(round(center_x))
            if 0 <= c < len(column_label_top):
                column_label_top[c] = max(column_label_top[c], label_top)

        placed.append({
            "x1": min(i1, i2),
            "x2": max(i1, i2),
            "label_top": label_top,
        })
        highest_text_y = max(highest_text_y, text_y)

    for spec in label_specs:
        ax.text(
            spec["x"],
            spec["y"],
            spec["label"],
            ha="center",
            va="bottom",
            fontsize=13.0,
            zorder=10,
            clip_on=False,
            bbox=dict(facecolor="white", edgecolor="none", boxstyle="square,pad=0.18"),
        )

    return highest_text_y

def common_axis_layout():
    return {
        "lower": -0.5,
        "tick_upper": 1.0,
        "ticks": np.arange(-0.5, 1.0 + 0.001, 0.25),
    }

def draw_point_ci_panel(ax, sub, pathway, pairwise_df, layout):
    sub = sub.set_index("role_name").loc[ROLE_ORDER].reset_index()
    x, upper_bounds = draw_points(ax, sub)

    draw_background_band(ax, ymin=-0.5, ymax=0.0)
    ax.axhline(0, color="black", lw=1.0, linestyle=":")
    ax.set_xticks(x)
    ax.set_xticklabels(SHORT, rotation=40, ha="right", rotation_mode="anchor")

    if pathway == "IC -> Incremental":
        ax.set_ylabel("Conditional relationship\nbetween IC and incremental innovation", fontsize=14.0)
    else:
        ax.set_ylabel("Conditional relationship\nbetween CC and radical innovation", fontsize=14.0)

    style_axes(ax)

    highest_text_y = draw_brackets_compact(ax, upper_bounds, panel_brackets(), pairwise_df)

    ylim_upper = max(layout["tick_upper"], highest_text_y + GAP)
    ax.set_ylim(layout["lower"], ylim_upper)
    ax.set_yticks(layout["ticks"])
    ax.set_xlim(-0.45, 3.45)

    tick_range_mid = 0.25
    yfrac = (tick_range_mid - layout["lower"]) / (ylim_upper - layout["lower"])
    ax.yaxis.set_label_coords(-0.15, yfrac)

    return highest_text_y

def save_single_panel(filename_base, sub, pathway, pairwise_df, layout):
    fig = plt.figure(figsize=(5.7, 5.9))
    ax = fig.add_axes([0.14, 0.16, 0.78, 0.76])

    draw_point_ci_panel(ax, sub, pathway, pairwise_df, layout)

    fig.savefig(OUT / f"{filename_base}.png", bbox_inches="tight", dpi=600)
    plt.close(fig)

def save_combined_figure(sub1, sub2, pairs1, pairs2, layout):
    fig = plt.figure(figsize=(11.3, 5.9))
    ax1 = fig.add_axes([0.06, 0.16, 0.39, 0.76])
    ax2 = fig.add_axes([0.55, 0.16, 0.39, 0.76])

    draw_point_ci_panel(ax1, sub1, "IC -> Incremental", pairs1, layout)
    draw_point_ci_panel(ax2, sub2, "CC -> Radical", pairs2, layout)

    fig.savefig(OUT / "Figure_9_Role_Pairwise_Comparisons_BW.png",
                bbox_inches="tight", dpi=600)
    plt.close(fig)


NUMERIC_CONTROLS = [
    "firm_size", "firm_age", "prior_innovation_stock",
    "prior_invention_stock", "prior_ai_genai_patent_stock",
    "direct_partners_log", "genai_use_intensity",
    "genai_adoption_maturity", "digital_capability",
]
FACTOR_CONTROLS = ["ownership_n", "industry_n", "province_n"]


def estimate_role_effects():
    data = pd.read_stata(DATA, convert_categoricals=False)
    required = [
        "ego_network_density", "network_centrality",
        "information_complementarity", "capability_complementarity",
        "incremental_innovation", "radical_innovation",
        *NUMERIC_CONTROLS, *FACTOR_CONTROLS,
    ]
    missing = [name for name in required if name not in data.columns]
    if missing:
        raise ValueError(f"Missing required Figure 9 variables: {missing}")
    if data[required].isna().any().any():
        raise ValueError("Figure 9 requires complete analysis-ready model variables.")

    md = data["ego_network_density"].median()
    mc = data["network_centrality"].median()
    data["role"] = np.select(
        [
            (data["ego_network_density"] < md) & (data["network_centrality"] < mc),
            (data["ego_network_density"] >= md) & (data["network_centrality"] < mc),
            (data["ego_network_density"] < md) & (data["network_centrality"] >= mc),
            (data["ego_network_density"] >= md) & (data["network_centrality"] >= mc),
        ],
        [1, 2, 3, 4],
    ).astype(int)
    if set(data["role"]) != {1, 2, 3, 4}:
        raise ValueError("All four median-defined roles must be observed.")

    controls = " + ".join(
        NUMERIC_CONTROLS + [f"C({name})" for name in FACTOR_CONTROLS]
    )
    slopes, pairs = [], []
    for pathway, outcome, focal, other in [
        ("IC -> Incremental", "incremental_innovation",
         "information_complementarity", "capability_complementarity"),
        ("CC -> Radical", "radical_innovation",
         "capability_complementarity", "information_complementarity"),
    ]:
        role_term = "C(role, Treatment(reference=1))"
        formula = f"{outcome} ~ {focal} * {role_term} + {other} + {controls}"
        model = smf.ols(formula, data=data, missing="raise").fit(
            cov_type="HC3", use_t=True
        )
        names = model.model.exog_names
        vectors = {}
        for role in range(1, 5):
            vector = np.zeros(len(names))
            vector[names.index(focal)] = 1.0
            if role > 1:
                vector[names.index(f"{focal}:{role_term}[T.{role}]")] = 1.0
            vectors[role] = vector
            result = contrast_result(model, vector)
            slopes.append({
                "pathway": pathway, "role": role,
                "role_name": ROLE_ORDER[role - 1],
                "N": int((data["role"] == role).sum()),
                "slope": result.pop("estimate"), **result,
            })
        for role_a, role_b in combinations(range(1, 5), 2):
            result = contrast_result(model, vectors[role_a] - vectors[role_b])
            pairs.append({
                "pathway": pathway,
                "role_a": role_a, "role_a_name": ROLE_ORDER[role_a - 1],
                "role_b": role_b, "role_b_name": ROLE_ORDER[role_b - 1],
                "difference_a_minus_b": result.pop("estimate"), **result,
            })

    slopes = pd.DataFrame(slopes)
    pairs = pd.DataFrame(pairs)
    pairs["p_holm"] = np.nan
    for _, group in pairs.groupby("pathway", sort=False):
        ordered = group.sort_values("p")
        adjusted = np.maximum.accumulate(
            ordered["p"].to_numpy() * np.arange(len(ordered), 0, -1)
        )
        pairs.loc[ordered.index, "p_holm"] = np.minimum(adjusted, 1.0)
    print(f"Figure 9 font: {ACTIVE_FONT}")
    print("Figure 9: role counts", data["role"].value_counts().sort_index().to_dict())
    print(f"Density median: {md:.12g}; centrality median: {mc:.12g}")
    print(pairs[["pathway", "role_a", "role_b", "p", "p_holm"]].to_string(index=False))
    return slopes, pairs


def contrast_result(model, vector):

    result = model.t_test(vector, use_t=True)
    estimate = float(np.asarray(result.effect).item())
    se = float(np.asarray(result.sd).item())
    lower, upper = np.asarray(result.conf_int(alpha=0.05)).ravel()
    return {
        "estimate": estimate, "se": se,
        "t": float(np.asarray(result.tvalue).item()),
        "p": float(np.asarray(result.pvalue).item()),
        "lb": float(lower), "ub": float(upper),
    }


def make_figure9():
    slopes, pairs = estimate_role_effects()

    sub1 = slopes[slopes["pathway"] == "IC -> Incremental"].copy()
    sub2 = slopes[slopes["pathway"] == "CC -> Radical"].copy()
    pairs1 = pairs[pairs["pathway"] == "IC -> Incremental"].copy()
    pairs2 = pairs[pairs["pathway"] == "CC -> Radical"].copy()

    layout = common_axis_layout()

    save_single_panel(
        "Figure_9A_Information_Complementarity_Incremental",
        sub1,
        "IC -> Incremental", pairs1, layout
    )
    save_single_panel(
        "Figure_9B_Capability_Complementarity_Radical",
        sub2,
        "CC -> Radical", pairs2, layout
    )
    save_combined_figure(sub1, sub2, pairs1, pairs2, layout)


if __name__ == "__main__":
    make_figure9()
