version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"
* Table G1

tempfile role_slope_results

capture program drop _assign_median_roles
program define _assign_median_roles
    quietly summarize ego_network_density, detail
    scalar MEDIAN_DENSITY = r(p50)
    quietly summarize network_centrality, detail
    scalar MEDIAN_CENTRALITY = r(p50)
    capture drop role
    generate byte role = .
    replace role = 1 if ego_network_density <  MEDIAN_DENSITY & network_centrality <  MEDIAN_CENTRALITY
    replace role = 2 if ego_network_density >= MEDIAN_DENSITY & network_centrality <  MEDIAN_CENTRALITY
    replace role = 3 if ego_network_density <  MEDIAN_DENSITY & network_centrality >= MEDIAN_CENTRALITY
    replace role = 4 if ego_network_density >= MEDIAN_DENSITY & network_centrality >= MEDIAN_CENTRALITY

    label define NETWORK_ROLE 1 "Peripheral Participant" 2 "Embedded Refiner" ///
        3 "Network Explorer" 4 "Integrative Coordinator", replace
    label values role NETWORK_ROLE
end

use "$ROOT/data/empirical_analysis.dta", clear
assert _N == 312
_assign_median_roles
quietly count if role == 1
assert r(N) == 66
quietly count if role == 2
assert r(N) == 90
quietly count if role == 3
assert r(N) == 88
quietly count if role == 4
assert r(N) == 68

local CONTROLS firm_size firm_age prior_innovation_stock prior_invention_stock ///
    prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
    genai_adoption_maturity digital_capability i.ownership_n i.industry_n i.province_n

quietly regress incremental_innovation ///
    c.information_complementarity##ib1.role capability_complementarity `CONTROLS', vce(hc3)
estimates store ROLE_INCREMENTAL
quietly regress radical_innovation ///
    c.capability_complementarity##ib1.role information_complementarity `CONTROLS', vce(hc3)
estimates store ROLE_RADICAL

tempname F3
postfile `F3' str20 pathway byte role str30 role_name double N slope se t p lb ub ///
    using `role_slope_results', replace
estimates restore ROLE_INCREMENTAL
forvalues r = 1/4 {
    quietly count if role == `r'
    local role_n = r(N)
    local role_name : label NETWORK_ROLE `r'
    if `r' == 1 quietly lincom _b[information_complementarity]
    else quietly lincom _b[information_complementarity] + _b[`r'.role#c.information_complementarity]
    post `F3' ("IC -> Incremental") (`r') ("`role_name'") (`role_n') ///
        (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (r(lb)) (r(ub))
}
estimates restore ROLE_RADICAL
forvalues r = 1/4 {
    quietly count if role == `r'
    local role_n = r(N)
    local role_name : label NETWORK_ROLE `r'
    if `r' == 1 quietly lincom _b[capability_complementarity]
    else quietly lincom _b[capability_complementarity] + _b[`r'.role#c.capability_complementarity]
    post `F3' ("CC -> Radical") (`r') ("`role_name'") (`role_n') ///
        (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (r(lb)) (r(ub))
}
postclose `F3'
use `role_slope_results', clear

capture restore, not
tempfile role_slopes
save `role_slopes', replace

tempfile pairwise_results

use "$ROOT/data/empirical_analysis.dta", clear
assert _N == 312
_assign_median_roles
quietly count if role == 1
assert r(N) == 66
quietly count if role == 2
assert r(N) == 90
quietly count if role == 3
assert r(N) == 88
quietly count if role == 4
assert r(N) == 68


local I1 "_b[information_complementarity]"
local I2 "(_b[information_complementarity]+_b[2.role#c.information_complementarity])"
local I3 "(_b[information_complementarity]+_b[3.role#c.information_complementarity])"
local I4 "(_b[information_complementarity]+_b[4.role#c.information_complementarity])"
local C1 "_b[capability_complementarity]"
local C2 "(_b[capability_complementarity]+_b[2.role#c.capability_complementarity])"
local C3 "(_b[capability_complementarity]+_b[3.role#c.capability_complementarity])"
local C4 "(_b[capability_complementarity]+_b[4.role#c.capability_complementarity])"

tempname F4
postfile `F4' str20 pathway byte role_a str30 role_a_name byte role_b str30 role_b_name ///
    double difference_a_minus_b se t p lb ub ///
    using `pairwise_results', replace
estimates restore ROLE_INCREMENTAL
foreach pair in "1 2" "1 3" "1 4" "2 3" "2 4" "3 4" {
    tokenize "`pair'"
    local a = `1'
    local b = `2'
    local name_a : label NETWORK_ROLE `a'
    local name_b : label NETWORK_ROLE `b'
    quietly lincom `I`a'' - `I`b''
    post `F4' ("IC -> Incremental") (`a') ("`name_a'") (`b') ("`name_b'") ///
        (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (r(lb)) (r(ub))
}
estimates restore ROLE_RADICAL
foreach pair in "1 2" "1 3" "1 4" "2 3" "2 4" "3 4" {
    tokenize "`pair'"
    local a = `1'
    local b = `2'
    local name_a : label NETWORK_ROLE `a'
    local name_b : label NETWORK_ROLE `b'
    quietly lincom `C`a'' - `C`b''
    post `F4' ("CC -> Radical") (`a') ("`name_a'") (`b') ("`name_b'") ///
        (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (r(lb)) (r(ub))
}
postclose `F4'
use `pairwise_results', clear
bysort pathway (p): generate double p_holm = min(1,p*(_N-_n+1))
by pathway: replace p_holm = max(p_holm,p_holm[_n-1]) if _n > 1
sort pathway role_a role_b

capture restore, not
tempfile role_comparisons
save `role_comparisons', replace
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",9)
putdocx paragraph
putdocx text ("Table G1. Role-Specific Slopes and Pairwise Comparisons"), bold
putdocx paragraph
putdocx text ("Panel A. Role-specific slopes"), bold
use `role_slopes', clear
generate byte path_id=cond(pathway=="IC -> Incremental",1,2)
keep role role_name slope se p path_id
reshape wide slope se p, i(role role_name) j(path_id)
sort role
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str110 c2 str110 c3 str110 c4 str110 c5 using `display_data', replace
post `DISPLAY' ("Role") ("Information complementarity and incremental innovation") ("") ("Capability complementarity and radical innovation") ("")
post `DISPLAY' ("") ("b (SE)") ("p") ("b (SE)") ("p")
forvalues i=1/`=_N' {
 local role = role_name[`i']
 local b1 = trim(string(slope1[`i'],"%9.3f")) + " (" + trim(string(se1[`i'],"%9.3f")) + ")"
 local p1 = cond(p1[`i']<0.001,"<0.001",trim(string(p1[`i'],"%6.3f")))
 local b2 = trim(string(slope2[`i'],"%9.3f")) + " (" + trim(string(se2[`i'],"%9.3f")) + ")"
 local p2 = cond(p2[`i']<0.001,"<0.001",trim(string(p2[`i'],"%6.3f")))
 post `DISPLAY' ("`role'") ("`b1'") ("`p1'") ("`b2'") ("`p2'")
}
postclose `DISPLAY'
use `display_data', clear
local nr = _N
putdocx table g1a = data("c1 c2 c3 c4 c5"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(2)
putdocx table g1a(.,.), font("Arial",9) valign(center)
putdocx table g1a(1/2,.), bold halign(center)
putdocx table g1a(3/`nr',1), halign(left)
putdocx table g1a(3/`nr',2/5), halign(center)
putdocx table g1a(1,4), colspan(2)
putdocx table g1a(1,2), colspan(2)
putdocx paragraph
putdocx text ("Panel B. Pairwise slope differences"), bold
use `role_comparisons', clear
generate byte path_id=cond(pathway=="IC -> Incremental",1,2)
keep role_a role_a_name role_b role_b_name difference_a_minus_b se p p_holm path_id
reshape wide difference_a_minus_b se p p_holm, i(role_a role_a_name role_b role_b_name) j(path_id)
sort role_a role_b
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str110 c2 str110 c3 str110 c4 str110 c5 str110 c6 str110 c7 using `display_data', replace
post `DISPLAY' ("Comparison") ("Information complementarity and incremental innovation") ("") ("") ("Capability complementarity and radical innovation") ("") ("")
post `DISPLAY' ("") ("Delta (SE)") ("p") ("Holm p") ("Delta (SE)") ("p") ("Holm p")
forvalues i=1/`=_N' {
 local cmp=role_a_name[`i'] + " - " + role_b_name[`i']
 local b1 = trim(string(difference_a_minus_b1[`i'],"%9.3f")) + " (" + trim(string(se1[`i'],"%9.3f")) + ")"
 local p1 = cond(p1[`i']<0.001,"<0.001",trim(string(p1[`i'],"%6.3f")))
 local h1 = cond(p_holm1[`i']<0.001,"<0.001",trim(string(p_holm1[`i'],"%6.3f")))
 local b2 = trim(string(difference_a_minus_b2[`i'],"%9.3f")) + " (" + trim(string(se2[`i'],"%9.3f")) + ")"
 local p2 = cond(p2[`i']<0.001,"<0.001",trim(string(p2[`i'],"%6.3f")))
 local h2 = cond(p_holm2[`i']<0.001,"<0.001",trim(string(p_holm2[`i'],"%6.3f")))
 post `DISPLAY' ("`cmp'") ("`b1'") ("`p1'") ("`h1'") ("`b2'") ("`p2'") ("`h2'")
}
postclose `DISPLAY'
use `display_data', clear
local nr = _N
putdocx table g1b = data("c1 c2 c3 c4 c5 c6 c7"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(2)
putdocx table g1b(.,.), font("Arial",9) valign(center)
putdocx table g1b(1/2,.), bold halign(center)
putdocx table g1b(3/`nr',1), halign(left)
putdocx table g1b(3/`nr',2/7), halign(center)
putdocx table g1b(1,5), colspan(3)
putdocx table g1b(1,2), colspan(3)
putdocx save "$ROOT/outputs/tables/Table_G1.docx", replace
