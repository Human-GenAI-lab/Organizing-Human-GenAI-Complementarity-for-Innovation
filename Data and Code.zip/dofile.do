version 16.0
set more off

* Run from the package root.
cd "D:\Data and Code"
confirm file "data/empirical_analysis.dta"

capture mkdir "outputs"
capture mkdir "outputs/tables"
capture mkdir "outputs/figures"

display as text "Package folder: `c(pwd)'"

foreach file in Table_1 Table_2 Table_3 Figure_8 {
    do "main/`file'.do"
}

foreach file in Table_E1 Table_F1 Table_F2 Table_F3 Table_F4 ///
                Table_G1 Table_G2 Table_H1 Table_H2 Table_H3 {
    do "appendix/`file'.do"
}

display as result "Tables saved in: `c(pwd)'/outputs/tables"
display as result "Figure 8 saved in: `c(pwd)'/outputs/figures"
display as result "Run main/Figure_9.py and main/Figure_10.py with Python for Figures 9 and 10."
