version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/survey_items.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table C2
local CONSTRUCTS IC CC GUI GAM DC
local IC_items IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10
local CC_items CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10
local GUI_items GUI1 GUI2 GUI3 GUI4
local GAM_items GAM1 GAM2 GAM3 GAM4
local DC_items DC1 DC2 DC3 DC4
local ALLITEMS `IC_items' `CC_items' `GUI_items' `GAM_items' `DC_items'

use "$ROOT/data/survey_items.dta", clear
assert _N == 312

quietly correlate `ALLITEMS'
matrix ITEMCORR = r(C)

mata:
R = st_matrix("ITEMCORR")
lo = (1,11,21,25,29)
hi = (10,20,24,28,32)
H = J(5,5,.)
for (i=1; i<=5; i++) {
    H[i,i] = 1
}
for (i=1; i<=5; i++) {
    wi = 0
    ni = 0
    for (a=lo[i]; a<=hi[i]; a++) {
        for (b=a+1; b<=hi[i]; b++) {
            wi = wi + abs(R[a,b])
            ni = ni + 1
        }
    }
    wi = wi/ni
    for (j=1; j<i; j++) {
        wj = 0
        nj = 0
        for (a=lo[j]; a<=hi[j]; a++) {
            for (b=a+1; b<=hi[j]; b++) {
                wj = wj + abs(R[a,b])
                nj = nj + 1
            }
        }
        wj = wj/nj
        hb = 0
        nb = 0
        for (a=lo[i]; a<=hi[i]; a++) {
            for (b=lo[j]; b<=hi[j]; b++) {
                hb = hb + abs(R[a,b])
                nb = nb + 1
            }
        }
        hb = hb/nb
        H[i,j] = hb/sqrt(wi*wj)
        H[j,i] = H[i,j]
    }
}
st_matrix("HTMT",H)
end

matrix rownames HTMT = IC CC GUI GAM DC
matrix colnames HTMT = IC CC GUI GAM DC
clear
svmat double HTMT, names(col)
generate str40 construct = ""
replace construct = "Information complementarity" in 1
replace construct = "Capability complementarity" in 2
replace construct = "GenAI use intensity" in 3
replace construct = "GenAI adoption maturity" in 4
replace construct = "Digital capability" in 5
order construct IC CC GUI GAM DC
assert _N == 5
assert !missing(IC,CC,GUI,GAM,DC)

capture putdocx clear
putdocx begin, pagesize(A4) font("Arial",9)
putdocx paragraph
putdocx text ("Table C2. Discriminant Validity: HTMT Ratios"), bold font("Arial",10.5)
putdocx table c2 = (6,6), ///
    border(all,single,D9D9D9) layout(autofitwindow) headerrow(1) ///
    cellmargin(top,1pt) cellmargin(bottom,1pt)
putdocx table c2(1,1) = ("Construct")
forvalues j=1/5 {
    putdocx table c2(1,`=`j'+1') = ("(`j')")
}
forvalues i=1/5 {
    local r = `i' + 1
    local ct = "(" + string(`i') + ") " + construct[`i']
    putdocx table c2(`r',1) = ("`ct'")
    forvalues j=1/5 {
        local cj = `j' + 1
        local v : word `j' of `CONSTRUCTS'
        local h = cond(`j'<`i',trim(string(`v'[`i'],"%6.3f")),cond(`j'==`i',"-",""))
        putdocx table c2(`r',`cj') = ("`h'")
    }
}
putdocx table c2(.,.), font("Arial",9) valign(center)
putdocx table c2(.,2/6), halign(center)
putdocx table c2(1,.), bold halign(center) shading(F2F2F2) ///
    border(top,single,000000) border(bottom,single,000000)
putdocx save "$ROOT/outputs/tables/Table_C2.docx", replace
