version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table F4
tempfile marker_diagnostics marker_results

use "$ROOT/data/survey_items.dta", clear
assert _N == 312

quietly alpha BLUE1 BLUE2 BLUE3
scalar BLUE_ALPHA = r(alpha)

egen double marker_score = rowmean(BLUE1 BLUE2 BLUE3)
egen double ic_score  = rowmean(IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10)
egen double cc_score  = rowmean(CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10)
egen double gui_score = rowmean(GUI1 GUI2 GUI3 GUI4)
egen double gam_score = rowmean(GAM1 GAM2 GAM3 GAM4)
egen double dc_score  = rowmean(DC1 DC2 DC3 DC4)

tempname MD
postfile `MD' str40 construct double marker_alpha marker_correlation ///
using `marker_diagnostics', replace
quietly correlate marker_score ic_score
matrix Q = r(C)
post `MD' ("Information complementarity") (BLUE_ALPHA) (Q[1,2])

quietly correlate marker_score cc_score
matrix Q = r(C)
post `MD' ("Capability complementarity") (BLUE_ALPHA) (Q[1,2])

quietly correlate marker_score gui_score
matrix Q = r(C)
post `MD' ("GenAI use intensity") (BLUE_ALPHA) (Q[1,2])

quietly correlate marker_score gam_score
matrix Q = r(C)
post `MD' ("GenAI adoption maturity") (BLUE_ALPHA) (Q[1,2])

quietly correlate marker_score dc_score
matrix Q = r(C)
post `MD' ("Digital capability") (BLUE_ALPHA) (Q[1,2])

postclose `MD'

use "$ROOT/data/survey_items.dta", clear
assert _N == 312

egen double marker_score = rowmean(BLUE1 BLUE2 BLUE3)

egen double ic_raw  = rowmean(IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10)
egen double cc_raw  = rowmean(CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10)
egen double gui_raw = rowmean(GUI1 GUI2 GUI3 GUI4)
egen double gam_raw = rowmean(GAM1 GAM2 GAM3 GAM4)
egen double dc_raw  = rowmean(DC1 DC2 DC3 DC4)

preserve
keep firm_id ic_raw cc_raw gui_raw gam_raw dc_raw
isid firm_id
merge 1:1 firm_id using "$ROOT/data/empirical_analysis.dta", ///
    keepusing(information_complementarity capability_complementarity ///
    genai_use_intensity genai_adoption_maturity digital_capability) ///
    assert(match) nogen
assert _N == 312
assert ic_raw == information_complementarity
assert cc_raw == capability_complementarity
assert gui_raw == genai_use_intensity
assert gam_raw == genai_adoption_maturity
assert dc_raw == digital_capability
restore

quietly regress ic_raw marker_score
predict double ic_marker_adj, residuals

quietly regress cc_raw marker_score
predict double cc_marker_adj, residuals

quietly regress gui_raw marker_score
predict double gui_marker_adj, residuals

quietly regress gam_raw marker_score
predict double gam_marker_adj, residuals

quietly regress dc_raw marker_score
predict double dc_marker_adj, residuals

keep firm_id marker_score ic_marker_adj cc_marker_adj ///
    gui_marker_adj gam_marker_adj dc_marker_adj

tempfile marker_adjusted
save `marker_adjusted', replace

use "$ROOT/data/empirical_analysis.dta", clear
merge 1:1 firm_id using `marker_adjusted', assert(match) nogen
assert _N == 312

quietly summarize ic_marker_adj, meanonly
generate double ic_marker_adj_c = ic_marker_adj - r(mean)

quietly summarize cc_marker_adj, meanonly
generate double cc_marker_adj_c = cc_marker_adj - r(mean)

local C firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log ///
gui_marker_adj gam_marker_adj dc_marker_adj ///
i.ownership_n i.industry_n i.province_n

tempname CM
postfile `CM' str8 test str80 statistic double estimate se p ///
using `marker_results', replace

quietly regress incremental_innovation ///
ic_marker_adj_c cc_marker_adj_c ///
ego_network_density_c network_centrality_c ///
`C', vce(hc3)

scalar EST = _b[ic_marker_adj_c]
scalar SE  = _se[ic_marker_adj_c]
scalar PV  = 2*ttail(e(df_r),abs(EST/SE))
post `CM' ("H1a") ("Marker-adjusted IC main effect") (EST) (SE) (PV)

quietly regress radical_innovation ///
ic_marker_adj_c cc_marker_adj_c ///
ego_network_density_c network_centrality_c ///
`C', vce(hc3)

scalar EST = _b[cc_marker_adj_c]
scalar SE  = _se[cc_marker_adj_c]
scalar PV  = 2*ttail(e(df_r),abs(EST/SE))
post `CM' ("H1b") ("Marker-adjusted CC main effect") (EST) (SE) (PV)

_pctile ego_network_density_c, p(25 75)
local dl = r(r1)
local dh = r(r2)

_pctile network_centrality_c, p(25 75)
local cl = r(r1)
local ch = r(r2)

quietly regress incremental_innovation ///
c.ic_marker_adj_c##c.ego_network_density_c##c.network_centrality_c ///
cc_marker_adj_c `C', vce(hc3)

scalar EST = _b[c.ic_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
scalar SE  = _se[c.ic_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
scalar PV  = 2*ttail(e(df_r),abs(EST/SE))
post `CM' ("H2a") ("Marker-adjusted three-way interaction") (EST) (SE) (PV)

lincom (`dh'-`dl')*_b[c.ic_marker_adj_c#c.ego_network_density_c] + ///
       (`cl'-`ch')*_b[c.ic_marker_adj_c#c.network_centrality_c] + ///
       ((`dh'*`cl')-(`dl'*`ch'))*_b[c.ic_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
post `CM' ("H2a") ("Marker-adjusted planned contrast: HDLC - LDHC") ///
    (r(estimate)) (r(se)) (r(p))

quietly regress radical_innovation ///
c.cc_marker_adj_c##c.ego_network_density_c##c.network_centrality_c ///
ic_marker_adj_c `C', vce(hc3)

scalar EST = _b[c.cc_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
scalar SE  = _se[c.cc_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
scalar PV  = 2*ttail(e(df_r),abs(EST/SE))
post `CM' ("H2b") ("Marker-adjusted three-way interaction") (EST) (SE) (PV)

lincom (`dl'-`dh')*_b[c.cc_marker_adj_c#c.ego_network_density_c] + ///
       (`ch'-`cl')*_b[c.cc_marker_adj_c#c.network_centrality_c] + ///
       ((`dl'*`ch')-(`dh'*`cl'))*_b[c.cc_marker_adj_c#c.ego_network_density_c#c.network_centrality_c]
post `CM' ("H2b") ("Marker-adjusted planned contrast: LDHC - HDLC") ///
    (r(estimate)) (r(se)) (r(p))

postclose `CM'

use `marker_results', clear

capture restore, not
tempfile adjusted
generate byte ord = .
replace ord=1 if test=="H1a"
replace ord=2 if test=="H2a" & strpos(statistic,"three-way")
replace ord=3 if test=="H2a" & strpos(statistic,"planned contrast")
replace ord=4 if test=="H1b"
replace ord=5 if test=="H2b" & strpos(statistic,"three-way")
replace ord=6 if test=="H2b" & strpos(statistic,"planned contrast")
keep ord estimate se p
rename (estimate se p) (adj_b adj_se adj_p)
save `adjusted', replace
use "$ROOT/data/empirical_analysis.dta", clear
local C firm_size firm_age prior_innovation_stock prior_invention_stock prior_ai_genai_patent_stock direct_partners_log genai_use_intensity genai_adoption_maturity digital_capability i.ownership_n i.industry_n i.province_n
_pctile ego_network_density_c, p(25 75)
local dl=r(r1)
local dh=r(r2)
_pctile network_centrality_c, p(25 75)
local cl=r(r1)
local ch=r(r2)
tempfile baseline
tempname BASE
postfile `BASE' byte ord double base_b base_se base_p using `baseline', replace
foreach path in IC CC {
 if "`path'"=="IC" {
  local y incremental_innovation
  local x information_complementarity_c
  local other capability_complementarity_c
  local k=1
 }
 else {
  local y radical_innovation
  local x capability_complementarity_c
  local other information_complementarity_c
  local k=4
 }
 quietly reg `y' `x' `other' ego_network_density_c network_centrality_c `C', vce(hc3)
 post `BASE' (`k') (_b[`x']) (_se[`x']) (2*ttail(e(df_r),abs(_b[`x']/_se[`x'])))
 quietly reg `y' c.`x'##c.ego_network_density_c##c.network_centrality_c `other' `C', vce(hc3)
 local triple c.`x'#c.ego_network_density_c#c.network_centrality_c
 post `BASE' (`k'+1) (_b[`triple']) (_se[`triple']) (2*ttail(e(df_r),abs(_b[`triple']/_se[`triple'])))
 local sign=cond("`path'"=="IC",1,-1)
 quietly lincom `sign'*((`dh'-`dl')*_b[c.`x'#c.ego_network_density_c] + (`cl'-`ch')*_b[c.`x'#c.network_centrality_c] + ((`dh'*`cl')-(`dl'*`ch'))*_b[c.`x'#c.ego_network_density_c#c.network_centrality_c])
 post `BASE' (`k'+2) (r(estimate)) (r(se)) (r(p))
}
postclose `BASE'
use `baseline', clear
merge 1:1 ord using `adjusted', assert(match) nogen
sort ord
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str32 c2 str32 c3 str32 c4 str32 c5 using `display_data', replace
post `DISPLAY' ("Term or contrast") ("Baseline") ("") ("Marker-adjusted") ("")
post `DISPLAY' ("") ("b (SE)") ("p") ("b (SE)") ("p")
forvalues i=1/6 {
 if `i'==1 post `DISPLAY' ("Panel A. Incremental innovation") ("") ("") ("") ("")
 if `i'==4 post `DISPLAY' ("Panel B. Radical innovation") ("") ("") ("") ("")
 local term ""
 if `i'==1 local term "Information complementarity (H1a)"
 if `i'==2 local term "IC x Density x Centrality"
 if `i'==3 local term "Planned contrast (H2a)"
 if `i'==4 local term "Capability complementarity (H1b)"
 if `i'==5 local term "CC x Density x Centrality"
 if `i'==6 local term "Planned contrast (H2b)"
 local bs = trim(string(base_b[`i'],"%9.3f")) + " (" + trim(string(base_se[`i'],"%9.3f")) + ")"
 local bp = cond(base_p[`i']<0.001,"<0.001",trim(string(base_p[`i'],"%6.3f")))
 local as = trim(string(adj_b[`i'],"%9.3f")) + " (" + trim(string(adj_se[`i'],"%9.3f")) + ")"
 local ap = cond(adj_p[`i']<0.001,"<0.001",trim(string(adj_p[`i'],"%6.3f")))
 post `DISPLAY' ("`term'") ("`bs'") ("`bp'") ("`as'") ("`ap'")
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",10)
putdocx paragraph
putdocx text ("Table F4. Marker-Adjusted Sensitivity Analyses"), bold
local nr = _N
putdocx table f4 = data("c1 c2 c3 c4 c5"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(2)
putdocx table f4(.,.), font("Arial",10) valign(center)
putdocx table f4(1/2,.), bold halign(center)
putdocx table f4(3/`nr',1), halign(left)
putdocx table f4(3/`nr',2/5), halign(center)
putdocx table f4(1,4), colspan(2)
putdocx table f4(1,2), colspan(2)
putdocx table f4(3,1), colspan(5)
putdocx table f4(3,.), bold
putdocx table f4(7,1), colspan(5)
putdocx table f4(7,.), bold
putdocx save "$ROOT/outputs/tables/Table_F4.docx", replace
