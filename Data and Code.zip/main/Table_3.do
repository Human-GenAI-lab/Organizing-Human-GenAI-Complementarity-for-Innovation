version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

tempfile numeric_results word_data

* Table 3

use "$ROOT/data/empirical_analysis.dta", clear

_pctile ego_network_density_c, p(25 75)
local dl = r(r1)
local dh = r(r2)

_pctile network_centrality_c, p(25 75)
local cl = r(r1)
local ch = r(r2)

tempname T3NUM
postfile `T3NUM' str4 path str12 row_type byte (condition_1 condition_2) ///
    str94 condition double (N estimate se t p df_r) ///
    using "`numeric_results'", replace

tempname T3
postfile `T3' ///
str94 c1 ///
str16 c2 ///
str16 c3 ///
str16 c4 ///
str16 c5 ///
using "`word_data'", replace

post `T3' ("Condition") ("Estimate") ("SE") ("t") ("p-value")

post `T3' ///
("Panel A. DV: Incremental Innovation (H2a)") ///
("") ("") ("") ("")

post `T3' ///
("IV: Information Complementarity") ///
("") ("") ("") ("")

quietly reg incremental_innovation ///
c.information_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
capability_complementarity_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)

quietly lincom ///
_b[information_complementarity_c] + ///
`dh' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dh' * `ch') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2a") ("slope") (1) (.) ///
    ("(1) High ego-network density, high firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(1) High ego-network density, high firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[information_complementarity_c] + ///
`dh' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dh' * `cl') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2a") ("slope") (2) (.) ///
    ("(2) High ego-network density, low firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(2) High ego-network density, low firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[information_complementarity_c] + ///
`dl' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dl' * `ch') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2a") ("slope") (3) (.) ///
    ("(3) Low ego-network density, high firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(3) Low ego-network density, high firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[information_complementarity_c] + ///
`dl' * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.information_complementarity_c#c.network_centrality_c] + ///
(`dl' * `cl') * _b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2a") ("slope") (4) (.) ///
    ("(4) Low ego-network density, low firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(4) Low ego-network density, low firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

post `T3' ///
("Hypothesized slope difference") ///
("") ("") ("") ("")

quietly lincom ///
(`dh'-`dl') * _b[c.information_complementarity_c#c.ego_network_density_c] + ///
(`cl'-`ch') * _b[c.information_complementarity_c#c.network_centrality_c] + ///
((`dh'*`cl')-(`dl'*`ch')) * ///
_b[c.information_complementarity_c#c.ego_network_density_c#c.network_centrality_c]

local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2a") ("contrast") (2) (3) ///
    ("(2) - (3)") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))

post `T3' ///
("(2) - (3)") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

post `T3' ///
("Panel B. DV: Radical Innovation (H2b)") ///
("") ("") ("") ("")

post `T3' ///
("IV: Capability Complementarity") ///
("") ("") ("") ("")

quietly reg radical_innovation ///
c.capability_complementarity_c##c.ego_network_density_c##c.network_centrality_c ///
information_complementarity_c ///
firm_size firm_age prior_innovation_stock prior_invention_stock ///
prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
genai_adoption_maturity digital_capability ///
i.ownership_n i.industry_n i.province_n, vce(hc3)

quietly lincom ///
_b[capability_complementarity_c] + ///
`dh' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dh' * `ch') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2b") ("slope") (1) (.) ///
    ("(1) High ego-network density, high firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(1) High ego-network density, high firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[capability_complementarity_c] + ///
`dh' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dh' * `cl') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2b") ("slope") (2) (.) ///
    ("(2) High ego-network density, low firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(2) High ego-network density, low firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[capability_complementarity_c] + ///
`dl' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`ch' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dl' * `ch') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2b") ("slope") (3) (.) ///
    ("(3) Low ego-network density, high firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(3) Low ego-network density, high firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

quietly lincom ///
_b[capability_complementarity_c] + ///
`dl' * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
`cl' * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
(`dl' * `cl') * _b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]
local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2b") ("slope") (4) (.) ///
    ("(4) Low ego-network density, low firm network centrality") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))
post `T3' ///
("(4) Low ego-network density, low firm network centrality") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

post `T3' ///
("Hypothesized slope difference") ///
("") ("") ("") ("")

quietly lincom ///
(`dl'-`dh') * _b[c.capability_complementarity_c#c.ego_network_density_c] + ///
(`ch'-`cl') * _b[c.capability_complementarity_c#c.network_centrality_c] + ///
((`dl'*`ch')-(`dh'*`cl')) * ///
_b[c.capability_complementarity_c#c.ego_network_density_c#c.network_centrality_c]

local es = trim(string(r(estimate),"%9.3f"))
local ss = trim(string(r(se),"%9.3f"))
local ts = trim(string(r(estimate)/r(se),"%9.3f"))
local ps = cond(r(p)<0.001,"<0.001",trim(string(r(p),"%6.3f")))

post `T3NUM' ("H2b") ("contrast") (3) (2) ///
    ("(3) - (2)") (e(N)) (r(estimate)) (r(se)) (r(estimate)/r(se)) (r(p)) (e(df_r))

post `T3' ///
("(3) - (2)") ///
("`es'") ("`ss'") ("`ts'") ("`ps'")

postclose `T3'

postclose `T3NUM'
use "`numeric_results'", clear
assert _N==10
assert inlist(path,"H2a","H2b")
assert !missing(N,estimate,se,t,p,df_r)

use "`word_data'", clear
assert _N==17
local nr = _N

capture putdocx clear
putdocx begin, pagesize(letter) font("Arial",10)

putdocx paragraph
putdocx text ("Table 3. "), bold
putdocx text ("Simple Slopes and Hypothesized Slope Differences for the Joint Moderation Effects")

putdocx table t3 = data("c1 c2 c3 c4 c5"), ///
border(all,nil) layout(autofitwindow) headerrow(1)

putdocx table t3(.,.), font("Arial",10) valign(center)

putdocx table t3(1,.), bold halign(center) ///
border(top,single,black) border(bottom,single,black)

putdocx table t3(2,1), colspan(5)
putdocx table t3(2,1), bold halign(left)

putdocx table t3(3,1), colspan(5)
putdocx table t3(3,1), italic halign(left)

putdocx table t3(4/7,1), halign(left)
putdocx table t3(4/7,2/5), halign(center)

putdocx table t3(8,1), colspan(5)
putdocx table t3(8,1), bold italic halign(left) ///
border(top,single,black)

putdocx table t3(9,.), bold
putdocx table t3(9,1), halign(left)
putdocx table t3(9,2/5), halign(center)
putdocx table t3(9,.), border(bottom,single,black)

putdocx table t3(10,1), colspan(5)
putdocx table t3(10,1), bold halign(left)

putdocx table t3(11,1), colspan(5)
putdocx table t3(11,1), italic halign(left)

putdocx table t3(12/15,1), halign(left)
putdocx table t3(12/15,2/5), halign(center)

putdocx table t3(16,1), colspan(5)
putdocx table t3(16,1), bold italic halign(left) ///
border(top,single,black)

putdocx table t3(17,.), bold
putdocx table t3(17,1), halign(left)
putdocx table t3(17,2/5), halign(center)
putdocx table t3(17,.), border(bottom,single,black)

putdocx save ///
"$ROOT/outputs/tables/Table_3.docx", ///
replace

