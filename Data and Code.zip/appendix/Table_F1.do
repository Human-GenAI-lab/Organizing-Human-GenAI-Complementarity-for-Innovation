version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table F1
tempfile work0

use "$ROOT/data/survey_items.dta", clear
assert _N == 312

tempname F
postfile `F' str38 model str90 structure double N chi2df cfi tli rmsea srmr ///
using `work0', replace

sem (IC -> IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10) ///
    (CC -> CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10) ///
    (GUI -> GUI1 GUI2 GUI3 GUI4) ///
    (GAM -> GAM1 GAM2 GAM3 GAM4) ///
    (DC -> DC1 DC2 DC3 DC4), ///
    latent(IC CC GUI GAM DC) nocapslatent method(mlmv)

quietly estat gof, stats(all)
post `F' ("Five-factor measurement model") ///
    ("IC, CC, GUI, GAM, and DC modeled separately") ///
    (e(N)) (r(chi2_ms)/r(df_ms)) (r(cfi)) (r(tli)) (r(rmsea)) (r(srmr))

use "$ROOT/data/survey_items.dta", clear

sem (COMP -> IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10 ///
    CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10) ///
    (GUI -> GUI1 GUI2 GUI3 GUI4) ///
    (GAM -> GAM1 GAM2 GAM3 GAM4) ///
    (DC -> DC1 DC2 DC3 DC4), ///
    latent(COMP GUI GAM DC) nocapslatent method(mlmv)

quietly estat gof, stats(all)
post `F' ("Combined-complementarity model") ///
    ("IC and CC combined; GUI, GAM, and DC modeled separately") ///
    (e(N)) (r(chi2_ms)/r(df_ms)) (r(cfi)) (r(tli)) (r(rmsea)) (r(srmr))

sem (ONE -> IC1 IC2 IC3 IC4 IC5 IC6 IC7 IC8 IC9 IC10 ///
    CC1 CC2 CC3 CC4 CC5 CC6 CC7 CC8 CC9 CC10 ///
    GUI1 GUI2 GUI3 GUI4 GAM1 GAM2 GAM3 GAM4 DC1 DC2 DC3 DC4), ///
    latent(ONE) nocapslatent method(mlmv)

quietly estat gof, stats(all)
post `F' ("Single-factor model") ///
    ("All substantive survey items loaded on one factor") ///
    (e(N)) (r(chi2_ms)/r(df_ms)) (r(cfi)) (r(tli)) (r(rmsea)) (r(srmr))

postclose `F'

use `work0', clear

capture restore, not
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str32 c2 str32 c3 str32 c4 str32 c5 str32 c6 using `display_data', replace
post `DISPLAY' ("Measurement model") ("Chi-square/df") ("CFI") ("TLI") ("RMSEA") ("SRMR")
forvalues i=1/`=_N' {
 local m = model[`i']
 if `i'==1 local m "Five-factor model"
 if `i'==2 local m "Four-factor model combining IC and CC"
 if `i'==3 local m "Single-factor model"
 post `DISPLAY' ("`m'") (trim(string(chi2df[`i'],"%5.2f"))) (trim(string(cfi[`i'],"%5.3f"))) (trim(string(tli[`i'],"%5.3f"))) (trim(string(rmsea[`i'],"%5.3f"))) (trim(string(srmr[`i'],"%5.3f")))
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",10)
putdocx paragraph
putdocx text ("Table F1. Confirmatory Factor Analysis Model Comparison"), bold
local nr = _N
putdocx table f1 = data("c1 c2 c3 c4 c5 c6"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(1)
putdocx table f1(.,.), font("Arial",10) valign(center)
putdocx table f1(1/1,.), bold halign(center)
putdocx table f1(2/`nr',1), halign(left)
putdocx table f1(2/`nr',2/6), halign(center)
putdocx save "$ROOT/outputs/tables/Table_F1.docx", replace
