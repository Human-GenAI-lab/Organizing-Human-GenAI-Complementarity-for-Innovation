version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"

* Table 1

use "$ROOT/data/empirical_analysis.dta", clear
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str32 c2 str32 c3 str32 c4 str32 c5 str32 c6 using `display_data', replace
post `DISPLAY' ("Construct") ("Obs.") ("Mean") ("SD") ("Min") ("Max")
quietly summarize information_complementarity
post `DISPLAY' ("Information complementarity") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize capability_complementarity
post `DISPLAY' ("Capability complementarity") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize ego_network_density
post `DISPLAY' ("Ego-network density") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize network_centrality
post `DISPLAY' ("Firm network centrality") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize incremental_innovation
post `DISPLAY' ("Incremental innovation") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize radical_innovation
post `DISPLAY' ("Radical innovation") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize genai_use_intensity
post `DISPLAY' ("GenAI use intensity") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize genai_adoption_maturity
post `DISPLAY' ("GenAI adoption maturity") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize digital_capability
post `DISPLAY' ("Digital capability") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize firm_size
post `DISPLAY' ("Firm size") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize firm_age
post `DISPLAY' ("Firm age") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize prior_innovation_stock
post `DISPLAY' ("Prior innovation stock") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize prior_invention_stock
post `DISPLAY' ("Prior invention patent stock") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize prior_ai_genai_patent_stock
post `DISPLAY' ("Prior AI/GenAI patent stock") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
quietly summarize direct_partners_log
post `DISPLAY' ("Direct supply-chain partners") (trim(string(r(N),"%9.0f"))) (trim(string(r(mean),"%9.3f"))) (trim(string(r(sd),"%9.3f"))) (trim(string(r(min),"%9.3f"))) (trim(string(r(max),"%9.3f")))
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) font("Arial",10)
putdocx paragraph
putdocx text ("Table 1. Descriptive Statistics"), bold
local nr = _N
putdocx table t1 = data("c1 c2 c3 c4 c5 c6"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(1)
putdocx table t1(.,.), font("Arial",10) valign(center)
putdocx table t1(1/1,.), bold halign(center)
putdocx table t1(2/`nr',1), halign(left)
putdocx table t1(2/`nr',2/6), halign(center)
putdocx save "$ROOT/outputs/tables/Table_1.docx", replace
