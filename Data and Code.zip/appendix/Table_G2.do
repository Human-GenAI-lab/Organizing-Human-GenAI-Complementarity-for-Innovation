version 16.0
set more off
global ROOT `"`c(pwd)'"'
confirm file "$ROOT/data/empirical_analysis.dta"
capture mkdir "$ROOT/outputs"
capture mkdir "$ROOT/outputs/tables"
* Table G2

tempfile classification_results

capture program drop _assign_median_roles
program define _assign_median_roles
    quietly summarize ego_network_density, detail
    scalar MEDIAN_DENSITY = r(p50)
    quietly summarize network_centrality, detail
    scalar MEDIAN_CENTRALITY = r(p50)
    capture drop role
    generate byte role = .
    replace role = 1 if ego_network_density <  MEDIAN_DENSITY & network_centrality <  MEDIAN_CENTRALITY
    replace role = 2 if ego_network_density >= MEDIAN_DENSITY & network_centrality <  MEDIAN_CENTRALITY
    replace role = 3 if ego_network_density <  MEDIAN_DENSITY & network_centrality >= MEDIAN_CENTRALITY
    replace role = 4 if ego_network_density >= MEDIAN_DENSITY & network_centrality >= MEDIAN_CENTRALITY

    label define NETWORK_ROLE 1 "Peripheral Participant" 2 "Embedded Refiner" ///
        3 "Network Explorer" 4 "Integrative Coordinator", replace
    label values role NETWORK_ROLE
end

capture program drop _role_contrast
program define _role_contrast, rclass
    syntax, Path(string)
    local C firm_size firm_age prior_innovation_stock prior_invention_stock ///
        prior_ai_genai_patent_stock direct_partners_log genai_use_intensity ///
        genai_adoption_maturity digital_capability i.ownership_n i.industry_n i.province_n
    if "`path'" == "H2a" {
        quietly regress incremental_innovation ///
            c.information_complementarity##ib1.role capability_complementarity `C', vce(hc3)
        quietly lincom (_b[information_complementarity]+_b[2.role#c.information_complementarity]) - ///
            (_b[information_complementarity]+_b[3.role#c.information_complementarity])
    }
    else {
        quietly regress radical_innovation ///
            c.capability_complementarity##ib1.role information_complementarity `C', vce(hc3)
        quietly lincom (_b[capability_complementarity]+_b[3.role#c.capability_complementarity]) - ///
            (_b[capability_complementarity]+_b[2.role#c.capability_complementarity])
    }
    return scalar estimate = r(estimate)
    return scalar se = r(se)
    return scalar p = r(p)
    return scalar lb = r(lb)
    return scalar ub = r(ub)
end

tempname F5
postfile `F5' str44 operationalization str20 pathway double N estimate se p lb ub ///
    using `classification_results', replace

use "$ROOT/data/empirical_analysis.dta", clear
capture drop role
capture drop role_name
_assign_median_roles
foreach path in H2a H2b {
    quietly _role_contrast, path(`path')
    local pathway = cond("`path'"=="H2a","IC -> Incremental","CC -> Radical")
    post `F5' ("Median-based quadrants") ("`pathway'") (_N) ///
        (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
}

use "$ROOT/data/empirical_analysis.dta", clear
capture drop role
capture drop role_name
quietly summarize ego_network_density, meanonly
local mean_d = r(mean)
quietly summarize network_centrality, meanonly
local mean_c = r(mean)
generate byte role = .
replace role = 1 if ego_network_density < `mean_d' & network_centrality < `mean_c'
replace role = 2 if ego_network_density >= `mean_d' & network_centrality < `mean_c'
replace role = 3 if ego_network_density < `mean_d' & network_centrality >= `mean_c'
replace role = 4 if ego_network_density >= `mean_d' & network_centrality >= `mean_c'
foreach path in H2a H2b {
    quietly _role_contrast, path(`path')
    local pathway = cond("`path'"=="H2a","IC -> Incremental","CC -> Radical")
    post `F5' ("Mean-split quadrants") ("`pathway'") (_N) ///
        (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
}

foreach cuts in "40 60" "33.333333 66.666667" {
    tokenize "`cuts'"
    local low = `1'
    local high = `2'
    use "$ROOT/data/empirical_analysis.dta", clear
capture drop role
capture drop role_name
    quietly _pctile ego_network_density, p(`low' `high')
    local dl = r(r1)
    local dh = r(r2)
    quietly _pctile network_centrality, p(`low' `high')
    local cl = r(r1)
    local ch = r(r2)
    keep if (ego_network_density <= `dl' | ego_network_density >= `dh') & ///
        (network_centrality <= `cl' | network_centrality >= `ch')
    generate byte role = .
    replace role = 1 if ego_network_density <= `dl' & network_centrality <= `cl'
    replace role = 2 if ego_network_density >= `dh' & network_centrality <= `cl'
    replace role = 3 if ego_network_density <= `dl' & network_centrality >= `ch'
    replace role = 4 if ego_network_density >= `dh' & network_centrality >= `ch'
    local specification = cond(`low'==40,"40th/60th-percentile extreme quadrants","Tercile extreme quadrants")
    foreach path in H2a H2b {
        quietly _role_contrast, path(`path')
        local pathway = cond("`path'"=="H2a","IC -> Incremental","CC -> Radical")
        post `F5' ("`specification'") ("`pathway'") (_N) ///
            (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
    }
}

use "$ROOT/data/empirical_analysis.dta", clear
capture drop role
capture drop role_name
egen double z_density = std(ego_network_density)
egen double z_centrality = std(network_centrality)
quietly _pctile z_density, p(25 75)
local dl = r(r1)
local dh = r(r2)
quietly _pctile z_centrality, p(25 75)
local cl = r(r1)
local ch = r(r2)
generate double dist1 = (z_density-`dl')^2 + (z_centrality-`cl')^2
generate double dist2 = (z_density-`dh')^2 + (z_centrality-`cl')^2
generate double dist3 = (z_density-`dl')^2 + (z_centrality-`ch')^2
generate double dist4 = (z_density-`dh')^2 + (z_centrality-`ch')^2
egen double min_distance = rowmin(dist1 dist2 dist3 dist4)
generate byte role = 1
replace role = 2 if dist2 == min_distance
replace role = 3 if dist3 == min_distance
replace role = 4 if dist4 == min_distance
foreach path in H2a H2b {
    quietly _role_contrast, path(`path')
    local pathway = cond("`path'"=="H2a","IC -> Incremental","CC -> Radical")
    post `F5' ("Ideal-type proximity assignment") ("`pathway'") (_N) ///
        (r(estimate)) (r(se)) (r(p)) (r(lb)) (r(ub))
}
postclose `F5'
use `classification_results', clear

capture restore, not
generate byte path_id=cond(pathway=="IC -> Incremental",1,2)
keep operationalization N estimate se p path_id
reshape wide estimate se p, i(operationalization N) j(path_id)
generate byte ord=.
replace ord=1 if operationalization=="Median-based quadrants"
replace ord=2 if operationalization=="Mean-split quadrants"
replace ord=3 if operationalization=="40th/60th-percentile extreme quadrants"
replace ord=4 if operationalization=="Tercile extreme quadrants"
replace ord=5 if operationalization=="Ideal-type proximity assignment"
sort ord
tempfile display_data
tempname DISPLAY
postfile `DISPLAY' str110 c1 str110 c2 str110 c3 str110 c4 str110 c5 str110 c6 using `display_data', replace
post `DISPLAY' ("Classification") ("N") ("Information complementarity and incremental innovation") ("") ("Capability complementarity and radical innovation") ("")
post `DISPLAY' ("") ("") ("Delta (SE)") ("p") ("Delta (SE)") ("p")
forvalues i=1/`=_N' {
 local cl = operationalization[`i']
 local ns=trim(string(N[`i'],"%9.0f"))
 local b1 = trim(string(estimate1[`i'],"%9.3f")) + " (" + trim(string(se1[`i'],"%9.3f")) + ")"
 local p1 = cond(p1[`i']<0.001,"<0.001",trim(string(p1[`i'],"%6.3f")))
 local b2 = trim(string(estimate2[`i'],"%9.3f")) + " (" + trim(string(se2[`i'],"%9.3f")) + ")"
 local p2 = cond(p2[`i']<0.001,"<0.001",trim(string(p2[`i'],"%6.3f")))
 post `DISPLAY' ("`cl'") ("`ns'") ("`b1'") ("`p1'") ("`b2'") ("`p2'")
}
postclose `DISPLAY'
use `display_data', clear
capture putdocx clear
putdocx begin, pagesize(letter) landscape font("Arial",9)
putdocx paragraph
putdocx text ("Table G2. Sensitivity to Role Classification"), bold
local nr = _N
putdocx table g2 = data("c1 c2 c3 c4 c5 c6"), border(all,single,D9D9D9) layout(autofitwindow) headerrow(2)
putdocx table g2(.,.), font("Arial",9) valign(center)
putdocx table g2(1/2,.), bold halign(center)
putdocx table g2(3/`nr',1), halign(left)
putdocx table g2(3/`nr',2/6), halign(center)
putdocx table g2(1,5), colspan(2)
putdocx table g2(1,3), colspan(2)
putdocx save "$ROOT/outputs/tables/Table_G2.docx", replace
